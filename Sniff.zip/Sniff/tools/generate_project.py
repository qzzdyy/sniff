#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 Sniff.xcodeproj/project.pbxproj
用法：python3 tools/generate_project.py
改动源文件清单（增删 .swift 文件）后重新运行即可。
"""
import hashlib
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_DIR = os.path.join(ROOT, "Sniff.xcodeproj")
PRODUCT_NAME = "Sniff"
BUNDLE_ID = "com.sniff.ios"

# (group, filename, 类型) —— 按分组排列
SOURCES = [
    ("App",     "SniffApp.swift"),
    ("Models",  "ResourceItem.swift"),
    ("Services", "ResourceStore.swift"),
    ("Services", "DownloadManager.swift"),
    ("Browser", "SniffWebView.swift"),
    ("Browser", "SniffSchemeHandler.swift"),
    ("Browser", "SniffScript.swift"),
    ("Browser", "SniffMessageHandler.swift"),
    ("Browser", "WebViewStore.swift"),
    ("Views",   "ContentView.swift"),
    ("Views",   "ResourceListView.swift"),
]
RESOURCES = [
    ("Resources", "Assets.xcassets"),
]


def uid(key: str) -> str:
    """确定性 24 位十六进制 UUID"""
    return hashlib.md5(key.encode()).hexdigest()[:24].upper()


def quote(s: str) -> str:
    """pbxproj 字符串：含特殊字符时加引号"""
    if s == "" or any(c in s for c in ' /"\\'):
        return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'
    return s


def main():
    os.makedirs(PROJECT_DIR, exist_ok=True)

    # 校验文件存在
    for group, name in SOURCES + RESOURCES:
        p = os.path.join(ROOT, "Sniff", group, name)
        if not os.path.exists(p):
            sys.exit(f"[ERROR] 缺少文件: Sniff/{group}/{name}")

    L = []          # 行缓冲
    w = L.append

    def section(title, rows):
        if not rows:
            return
        w(f"/* Begin {title} section */")
        L.extend(rows)
        w(f"/* End {title} section */")
        w("")

    # ---------- UUID 分配 ----------
    u_buildfile = {}   # (group,name) -> build file uuid
    u_fileref = {}     # (group,name) -> file ref uuid
    for group, name in SOURCES + RESOURCES:
        u_buildfile[(group, name)] = uid("buildfile:" + group + "/" + name)
        u_fileref[(group, name)] = uid("fileref:" + group + "/" + name)

    u_product = uid("product")
    u_plist = uid("fileref:Info.plist")
    u_group_main = uid("group:main")
    u_group_sniff = uid("group:Sniff")
    u_group_app = uid("group:App")
    u_group_models = uid("group:Models")
    u_group_services = uid("group:Services")
    u_group_browser = uid("group:Browser")
    u_group_views = uid("group:Views")
    u_group_resources = uid("group:Resources")
    u_group_frameworks = uid("group:Frameworks")
    u_group_products = uid("group:Products")
    u_target = uid("target")
    u_project = uid("project")
    u_sources_phase = uid("phase:sources")
    u_resources_phase = uid("phase:resources")
    u_frameworks_phase = uid("phase:frameworks")
    u_cfglist_project = uid("cfglist:project")
    u_cfglist_target = uid("cfglist:target")
    u_cfg_project_debug = uid("cfg:project:debug")
    u_cfg_project_release = uid("cfg:project:release")
    u_cfg_target_debug = uid("cfg:target:debug")
    u_cfg_target_release = uid("cfg:target:release")

    # ---------- PBXBuildFile ----------
    rows = []
    for group, name in SOURCES:
        rows.append(f"\t\t{u_buildfile[(group,name)]} /* {name} in Sources */ = {{isa = PBXBuildFile; fileRef = {u_fileref[(group,name)]} /* {name} */; }};")
    for group, name in RESOURCES:
        rows.append(f"\t\t{u_buildfile[(group,name)]} /* {name} in Resources */ = {{isa = PBXBuildFile; fileRef = {u_fileref[(group,name)]} /* {name} */; }};")
    section("PBXBuildFile", rows)

    # ---------- PBXFileReference ----------
    rows = []
    for group, name in SOURCES + RESOURCES:
        is_swift = name.endswith(".swift")
        ftype = "sourcecode.swift" if is_swift else "folder.assetcatalog"
        rows.append(f"\t\t{u_fileref[(group,name)]} /* {name} */ = {{isa = PBXFileReference; lastKnownFileType = {ftype}; path = {quote(name)}; sourceTree = \"<group>\"; }};")
    rows.append(f"\t\t{u_product} /* {PRODUCT_NAME}.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = {PRODUCT_NAME}.app; sourceTree = BUILT_PRODUCTS_DIR; }};")
    rows.append(f"\t\t{u_plist} /* Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = \"<group>\"; }};")
    section("PBXFileReference", rows)

    # ---------- PBXFrameworksBuildPhase ----------
    rows = [f"\t\t{u_frameworks_phase} /* Frameworks */ = {{",
            "\t\t\tisa = PBXFrameworksBuildPhase;",
            "\t\t\tbuildActionMask = 2147483647;",
            "\t\t\tfiles = (",
            "\t\t\t);",
            "\t\t\trunOnlyForDeploymentPostprocessing = 0;",
            "\t\t};"]
    section("PBXFrameworksBuildPhase", rows)

    # ---------- PBXGroup ----------
    def group_body(uuid, children, name=None, path=None, sourceTree='"<group>"'):
        out = [f"\t\t{uuid} /* {name or ''} */ = {{", "\t\t\tisa = PBXGroup;",
               "\t\t\tchildren = ("]
        for c, comment in children:
            out.append(f"\t\t\t\t{c} /* {comment} */,")
        out.append("\t\t\t);")
        if name:
            out.append(f"\t\t\tname = {quote(name)};")
        if path:
            out.append(f"\t\t\tpath = {quote(path)};")
        out.append(f"\t\t\tsourceTree = {sourceTree};")
        out.append("\t\t};")
        return out

    rows = []
    rows += group_body(u_group_main, [(u_group_sniff, "Sniff"), (u_group_frameworks, "Frameworks"), (u_group_products, "Products")])
    rows += group_body(u_group_sniff,
                       [(u_group_app, "App"), (u_group_models, "Models"), (u_group_services, "Services"),
                        (u_group_browser, "Browser"), (u_group_views, "Views"), (u_group_resources, "Resources")],
                       name="Sniff", path="Sniff")
    for guuid, gname, items in [
        (u_group_app, "App", [s for s in SOURCES if s[0] == "App"]),
        (u_group_models, "Models", [s for s in SOURCES if s[0] == "Models"]),
        (u_group_services, "Services", [s for s in SOURCES if s[0] == "Services"]),
        (u_group_browser, "Browser", [s for s in SOURCES if s[0] == "Browser"]),
        (u_group_views, "Views", [s for s in SOURCES if s[0] == "Views"]),
    ]:
        rows += group_body(guuid, [(u_fileref[(g, n)], n) for g, n in items], name=gname, path=gname)
    res_children = [(u_fileref[RESOURCES[0]], "Assets.xcassets"),
                    (u_plist, "Info.plist")]
    rows += group_body(u_group_resources, res_children, name="Resources", path="Resources")
    rows += group_body(u_group_frameworks, [], name="Frameworks")
    rows += group_body(u_group_products, [(u_product, f"{PRODUCT_NAME}.app")], name="Products")
    section("PBXGroup", rows)

    # ---------- PBXNativeTarget ----------
    rows = [f"\t\t{u_target} /* {PRODUCT_NAME} */ = {{",
            "\t\t\tisa = PBXNativeTarget;",
            f"\t\t\tbuildConfigurationList = {u_cfglist_target} /* Build configuration list for PBXNativeTarget \"Sniff\" */;",
            "\t\t\tbuildPhases = (",
            f"\t\t\t\t{u_sources_phase} /* Sources */,",
            f"\t\t\t\t{u_frameworks_phase} /* Frameworks */,",
            f"\t\t\t\t{u_resources_phase} /* Resources */,",
            "\t\t\t);",
            "\t\t\tbuildRules = (",
            "\t\t\t);",
            "\t\t\tdependencies = (",
            "\t\t\t);",
            f"\t\t\tname = {PRODUCT_NAME};",
            f"\t\t\tproductName = {PRODUCT_NAME};",
            f"\t\t\tproductReference = {u_product} /* {PRODUCT_NAME}.app */;",
            "\t\t\tproductType = \"com.apple.product-type.application\";",
            "\t\t};"]
    section("PBXNativeTarget", rows)

    # ---------- PBXProject ----------
    rows = [f"\t\t{u_project} /* Project object */ = {{",
            "\t\t\tisa = PBXProject;",
            "\t\t\tattributes = {",
            "\t\t\t\tBuildIndependentTargetsInParallel = 1;",
            "\t\t\t\tLastUpgradeCheck = 1500;",
            "\t\t\t\tTargetAttributes = {",
            f"\t\t\t\t\t{u_target} = {{",
            "\t\t\t\t\t\tCreatedOnToolsVersion = 15.0;",
            "\t\t\t\t\t};",
            "\t\t\t\t};",
            "\t\t\t};",
            f"\t\t\tbuildConfigurationList = {u_cfglist_project} /* Build configuration list for PBXProject \"Sniff\" */;",
            "\t\t\tcompatibilityVersion = \"Xcode 14.0\";",
            "\t\t\tdevelopmentRegion = en;",
            "\t\t\thasScannedForEncodings = 0;",
            "\t\t\tknownRegions = (",
            "\t\t\t\ten,",
            "\t\t\t\tBase,",
            "\t\t\t\t\"zh_CN\",",
            "\t\t\t);",
            f"\t\t\tmainGroup = {u_group_main};",
            f"\t\t\tproductRefGroup = {u_group_products} /* Products */;",
            "\t\t\tprojectDirPath = \"\";",
            "\t\t\tprojectRoot = \"\";",
            "\t\t\ttargets = (",
            f"\t\t\t\t{u_target} /* {PRODUCT_NAME} */,",
            "\t\t\t);",
            "\t\t};"]
    section("PBXProject", rows)

    # ---------- PBXResourcesBuildPhase ----------
    rows = [f"\t\t{u_resources_phase} /* Resources */ = {{",
            "\t\t\tisa = PBXResourcesBuildPhase;",
            "\t\t\tbuildActionMask = 2147483647;",
            "\t\t\tfiles = ("]
    for group, name in RESOURCES:
        rows.append(f"\t\t\t\t{u_buildfile[(group,name)]} /* {name} in Resources */,")
    rows += ["\t\t\t);",
             "\t\t\trunOnlyForDeploymentPostprocessing = 0;",
             "\t\t};"]
    section("PBXResourcesBuildPhase", rows)

    # ---------- PBXSourcesBuildPhase ----------
    rows = [f"\t\t{u_sources_phase} /* Sources */ = {{",
            "\t\t\tisa = PBXSourcesBuildPhase;",
            "\t\t\tbuildActionMask = 2147483647;",
            "\t\t\tfiles = ("]
    for group, name in SOURCES:
        rows.append(f"\t\t\t\t{u_buildfile[(group,name)]} /* {name} in Sources */,")
    rows += ["\t\t\t);",
             "\t\t\trunOnlyForDeploymentPostprocessing = 0;",
             "\t\t};"]
    section("PBXSourcesBuildPhase", rows)

    # ---------- XCBuildConfiguration ----------
    def settings_block(rows, settings, indent="\t\t\t\t"):
        rows.append(f"{indent}buildSettings = {{")
        for k, v in settings:
            rows.append(f"{indent}\t{k} = {v};")
        rows.append(f"{indent}}};")

    project_common = [
        ("ALWAYS_SEARCH_USER_PATHS", "NO"),
        ("CLANG_ANALYZER_NONNULL", "YES"),
        ("CLANG_ENABLE_MODULES", "YES"),
        ("CLANG_ENABLE_OBJC_ARC", "YES"),
        ("ENABLE_STRICT_OBJC_MSGSEND", "YES"),
        ("ENABLE_USER_SCRIPT_SANDBOX", "YES"),
        ("GCC_C_LANGUAGE_STANDARD", "gnu17"),
        ("GCC_DYNAMIC_NO_PIC", "NO"),
        ("GCC_NO_COMMON_BLOCKS", "YES"),
        ("GCC_PREPROCESSOR_DEFINITIONS", "(\n\t\t\t\t\t\"DEBUG=1\",\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t)"),
        ("GCC_WARN_64_TO_32_BIT_CONVERSION", "YES"),
        ("GCC_WARN_ABOUT_RETURN_TYPE", "YES_ERROR"),
        ("GCC_WARN_UNINITIALIZED_AUTOS", "YES_AGGRESSIVE"),
        ("GCC_WARN_UNUSED_FUNCTION", "YES"),
        ("GCC_WARN_UNUSED_VARIABLE", "YES"),
        ("IPHONEOS_DEPLOYMENT_TARGET", "16.0"),
        ("SDKROOT", "iphoneos"),
        ("SWIFT_VERSION", "5.0"),
        ("TARGETED_DEVICE_FAMILY", "\"1,2\""),
        ("COREML_CODEGEN_LANGUAGE", "Swift"),
    ]
    target_common = [
        ("ASSETCATALOG_COMPILER_APPICON_NAME", "AppIcon"),
        ("ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME", "AccentColor"),
        ("CODE_SIGN_ENTITLEMENTS", '""'),
        ("CODE_SIGN_STYLE", "Automatic"),
        ("CURRENT_PROJECT_VERSION", "1"),
        ("DEVELOPMENT_TEAM", '""'),
        ("ENABLE_PREVIEWS", "YES"),
        ("GENERATE_INFOPLIST", "NO"),
        ("INFOPLIST_FILE", "Sniff/Resources/Info.plist"),
        ("LD_RUNPATH_SEARCH_PATHS", "(\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t\t\"@executable_path/Frameworks\",\n\t\t\t\t)"),
        ("MARKETING_VERSION", "1.0"),
        ("PRODUCT_BUNDLE_IDENTIFIER", f'"{BUNDLE_ID}"'),
        ("PRODUCT_NAME", '"$(TARGET_NAME)"'),
        ("SWIFT_EMIT_LOC_STRINGS", "YES"),
        ("SWIFT_VERSION", "5.0"),
        ("TARGETED_DEVICE_FAMILY", "\"1,2\""),
        ("IPHONEOS_DEPLOYMENT_TARGET", "16.0"),
    ]
    release_project = [(k, "NO" if v.startswith('("DEBUG') else v) for k, v in project_common]
    release_project = [(k, ("(\n\t\t\t\t\t\"$(inherited)\",\n\t\t\t\t)" if k == "GCC_PREPROCESSOR_DEFINITIONS" else v)) for k, v in release_project]
    debug_target = target_common + [("SWIFT_ACTIVE_COMPILATION_CONDITIONS", '"DEBUG"'),
                                    ("SWIFT_OPTIMIZATION_LEVEL", '"-Onone"')]
    release_target = target_common + [("SWIFT_COMPILATION_MODE", "wholemodule"),
                                      ("SWIFT_OPTIMIZATION_LEVEL", '"-O"')]

    rows = [f"\t\t{u_cfg_project_debug} /* Debug */ = {{", "\t\t\tisa = XCBuildConfiguration;"]
    settings_block(rows, project_common); rows.append("\t\t};")
    rows.append(f"\t\t{u_cfg_project_release} /* Release */ = {{")
    rows.append("\t\t\tisa = XCBuildConfiguration;")
    settings_block(rows, release_project); rows.append("\t\t};")
    rows.append(f"\t\t{u_cfg_target_debug} /* Debug */ = {{")
    rows.append("\t\t\tisa = XCBuildConfiguration;")
    settings_block(rows, debug_target); rows.append("\t\t};")
    rows.append(f"\t\t{u_cfg_target_release} /* Release */ = {{")
    rows.append("\t\t\tisa = XCBuildConfiguration;")
    settings_block(rows, release_target); rows.append("\t\t};")
    section("XCBuildConfiguration", rows)

    # ---------- XCConfigurationList ----------
    rows = [f"\t\t{u_cfglist_project} /* Build configuration list for PBXProject \"Sniff\" */ = {{",
            "\t\t\tisa = XCConfigurationList;",
            "\t\t\tbuildConfigurations = (",
            f"\t\t\t\t{u_cfg_project_debug} /* Debug */,",
            f"\t\t\t\t{u_cfg_project_release} /* Release */,",
            "\t\t\t);",
            "\t\t\tdefaultConfigurationIsVisible = 0;",
            "\t\t\tdefaultConfigurationName = Release;",
            "\t\t};",
            f"\t\t{u_cfglist_target} /* Build configuration list for PBXNativeTarget \"Sniff\" */ = {{",
            "\t\t\tisa = XCConfigurationList;",
            "\t\t\tbuildConfigurations = (",
            f"\t\t\t\t{u_cfg_target_debug} /* Debug */,",
            f"\t\t\t\t{u_cfg_target_release} /* Release */,",
            "\t\t\t);",
            "\t\t\tdefaultConfigurationIsVisible = 0;",
            "\t\t\tdefaultConfigurationName = Release;",
            "\t\t};"]
    section("XCConfigurationList", rows)

    # ---------- 组装 ----------
    out = ["// !$*UTF8*$!", "{", "\tarchiveVersion = 1;", "\tclasses = {", "\t};",
           "\tobjectVersion = 56;", "\tobjects = {", ""]
    out += L
    out += ["\t};", f"\trootObject = {u_project} /* Project object */;", "}", ""]

    pbx = os.path.join(PROJECT_DIR, "project.pbxproj")
    with open(pbx, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print(f"  ✓ {os.path.relpath(pbx, ROOT)}")

    # ---------- 自校验 ----------
    import re
    with open(pbx, encoding="utf-8") as f:
        content = f.read()
    defined = set(re.findall(r"^\t\t([0-9A-F]{24}) ", content, re.M))
    referenced = set(re.findall(r"[0-9A-F]{24}", content))
    dangling = referenced - defined
    if dangling:
        sys.exit(f"[ERROR] 存在未定义对象引用: {sorted(dangling)}")
    print(f"  ✓ 自校验通过：{len(defined)} 个对象，无悬空引用，{len(SOURCES)} 个源文件 + {len(RESOURCES)} 个资源")


if __name__ == "__main__":
    main()
