import Foundation
import WebKit

/// 拦截 WKWebView 的所有 http/https 请求：
/// - 流式转发响应（不全量进内存，视频 range 请求也能扛）
/// - 顺手记录 Content-Type / 扩展名命中的媒体资源
///
/// 说明：Cookie 由 WKWebsiteDataStore.httpCookieStore 统一管理，
/// WebKit 会自动注入到 scheme task 的请求头中，无需手动同步。
final class SniffSchemeHandler: NSObject, WKURLSchemeHandler, URLSessionDataDelegate {

    private let store: ResourceStore
    private var session: URLSession!
    /// taskIdentifier -> 正在进行的 scheme task
    private var pending: [Int: WKURLSchemeTask] = [:]
    private let lock = NSLock()

    init(store: ResourceStore) {
        self.store = store
        super.init()
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.httpMaximumConnectionsPerHost = 6
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }

    // MARK: - WKURLSchemeHandler

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        let task = session.dataTask(with: urlSchemeTask.request)
        lock.lock()
        pending[task.taskIdentifier] = urlSchemeTask
        lock.unlock()
        task.resume()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        lock.lock()
        let entry = pending.first(where: { $0.value === urlSchemeTask })
        if let id = entry?.key { pending.removeValue(forKey: id) }
        lock.unlock()
        if let id = entry?.key {
            session.getAllTasks { tasks in
                tasks.first { $0.taskIdentifier == id }?.cancel()
            }
        }
    }

    // MARK: - URLSessionDataDelegate（流式转发）

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        lock.lock()
        let schemeTask = pending[dataTask.taskIdentifier]
        lock.unlock()
        completionHandler(.allow)
        schemeTask?.didReceive(response)

        // 嗅探：Content-Type 命中媒体
        if let http = response as? HTTPURLResponse, let url = http.url {
            let mime = http.value(forHTTPHeaderField: "Content-Type") ?? ""
            if ResourceStore.classify(url: url, mime: mime) != nil {
                let length = http.value(forHTTPHeaderField: "Content-Length").flatMap(Int64.init)
                store.add(url: url, mime: mime, contentLength: length)
            }
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        let schemeTask = pending[dataTask.taskIdentifier]
        lock.unlock()
        schemeTask?.didReceive(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock()
        let schemeTask = pending.removeValue(forKey: task.taskIdentifier)
        lock.unlock()
        if let error {
            schemeTask?.didFailWithError(error)
        } else {
            schemeTask?.didFinish()
        }
    }
}
