import Foundation

/// 注入到网页里的嗅探脚本：
/// 1. 扫描 DOM 中的 video/audio/source/img 与链接
/// 2. 读取 performance 资源时间线
/// 3. 包装 fetch/XHR 抓动态加载地址
/// 4. MutationObserver + 定时重扫兜底懒加载
enum SniffScript {

    static func source() -> String {
        return """
        (function () {
        if (window.__sniffInjected) return;
        window.__sniffInjected = true;

        var seen = {};
        var EXT = /\.(mp4|m4v|mov|mkv|webm|flv|3gp|mp3|m4a|aac|wav|flac|ogg|opus|m3u8|mpd|jpg|jpeg|png|gif|webp|bmp|heic|svg)(\\?|#|$)/i;

        function abs(u) {
            if (!u) return null;
            u = String(u).trim();
            if (!u || u.indexOf('data:') === 0 || u.indexOf('blob:') === 0) return null;
            try { return new URL(u, location.href).href; } catch (e) { return null; }
        }
        function push(u, type) {
            u = abs(u);
            if (!u || seen[u]) return;
            seen[u] = 1;
            try {
                window.webkit.messageHandlers.sniff.postMessage({ url: u, type: type || '' });
            } catch (e) {}
        }
        function scan() {
            try {
                var els = document.querySelectorAll('video,audio,source,img,[style*="background-image"]');
                for (var i = 0; i < els.length; i++) {
                    var el = els[i];
                    push(el.currentSrc || el.src || el.getAttribute('src'), el.tagName);
                    push(el.poster, 'poster');
                    var bg = el.style && el.style.backgroundImage;
                    if (bg) {
                        var m = bg.match(/url\\(["']?(.*?)["']?\\)/);
                        if (m) push(m[1], 'css');
                    }
                }
                var links = document.querySelectorAll('a[href]');
                for (var j = 0; j < links.length; j++) push(links[j].href, 'link');
                var perf = performance.getEntriesByType('resource');
                for (var k = 0; k < perf.length; k++) push(perf[k].name, 'perf');
            } catch (e) {}
        }

        // fetch / XHR 包装
        var of = window.fetch;
        if (of) {
            window.fetch = function () {
                try { push(arguments[0] instanceof Request ? arguments[0].url : arguments[0], 'fetch'); } catch (e) {}
                return of.apply(this, arguments);
            };
        }
        var oo = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function () {
            try { push(arguments[1], 'xhr'); } catch (e) {}
            return oo.apply(this, arguments);
        };

        // 动态内容
        var timer = null;
        var mo = new MutationObserver(function () {
            if (timer) return;
            timer = setTimeout(function () { timer = null; scan(); }, 800);
        });
        mo.observe(document.documentElement, { childList: true, subtree: true });
        setInterval(scan, 3000);
        scan();
        document.addEventListener('DOMContentLoaded', scan);
        window.addEventListener('load', scan);
        })();
        """
    }
}
