import Foundation

/// 注入到网页里的嗅探脚本（用 Swift 原始字符串，JS 里的反斜杠原样保留）：
/// 1. 扫描 DOM 中的 video/audio/source/img/poster/背景图/链接
/// 2. PerformanceObserver + performance 时间线，抓所有网络资源
/// 3. 包装 fetch/XHR 抓动态接口
/// 4. 正则扫 HTML 源码里的媒体直链（视频站常见的 JSON 配置）
/// 5. MutationObserver + 定时重扫，兜底懒加载
enum SniffScript {

    static func source() -> String {
        return #"""
        (function () {
        if (window.__sniffInjected) return;
        window.__sniffInjected = true;

        var seen = {};

        function abs(u) {
            if (!u) return null;
            u = String(u).trim();
            if (!u || u.indexOf('data:') === 0 || u.indexOf('blob:') === 0) return null;
            try { return new URL(u, location.href).href; } catch (e) { return null; }
        }

        function push(u, type, size) {
            u = abs(u);
            if (!u || seen[u]) return;
            seen[u] = 1;
            try {
                window.webkit.messageHandlers.sniff.postMessage({ url: u, type: type || '', size: size || 0 });
            } catch (e) {}
        }

        function scanDom() {
            try {
                var els = document.querySelectorAll('video,audio,source,img,[style*="background-image"]');
                for (var i = 0; i < els.length; i++) {
                    var el = els[i];
                    push(el.currentSrc || el.src || el.getAttribute('src'), el.tagName);
                    push(el.poster, 'poster');
                    var bg = el.style && el.style.backgroundImage;
                    if (bg) {
                        var m = bg.match(/url\(["']?(.*?)["']?\)/);
                        if (m) push(m[1], 'css');
                    }
                }
                var links = document.querySelectorAll('a[href]');
                for (var j = 0; j < links.length; j++) push(links[j].href, 'link');
            } catch (e) {}
        }

        function scanPerf() {
            try {
                var perf = performance.getEntriesByType('resource');
                for (var k = 0; k < perf.length; k++) {
                    var e = perf[k];
                    push(e.name, 'net', e.transferSize || e.encodedBodySize || 0);
                }
            } catch (e) {}
        }

        function scanHtml() {
            try {
                var html = document.documentElement ? document.documentElement.innerHTML : '';
                if (!html) return;
                if (html.length > 2000000) html = html.slice(0, 2000000);
                var re = /https?:\/\/[^\s"'<>\\]+?\.(?:mp4|m3u8|mpd|mov|m4v|mkv|webm|mp3|m4a|aac|flac|wav|ogg|opus|jpe?g|png|gif|webp|bmp|heic)(?:\?[^\s"'<>\\]*)?/gi;
                var m, n = 0;
                while ((m = re.exec(html)) !== null && n < 300) {
                    push(m[0], 'html');
                    n++;
                }
            } catch (e) {}
        }

        function scanAll() { scanDom(); scanPerf(); scanHtml(); }

        var of = window.fetch;
        if (of) {
            window.fetch = function () {
                try { push(arguments[0] instanceof Request ? arguments[0].url : arguments[0], 'fetch'); } catch (e) {}
                return of.apply(this, arguments);
            };
        }

        var oo = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function () {
            try { push(arguments[1], 'xhr'); } catch (e) {}
            return oo.apply(this, arguments);
        };

        try {
            new PerformanceObserver(function (list) {
                var items = list.getEntries();
                for (var i = 0; i < items.length; i++) push(items[i].name, 'net', items[i].transferSize || 0);
            }).observe({ entryTypes: ['resource'] });
        } catch (e) {}

        var timer = null;
        var mo = new MutationObserver(function () {
            if (timer) return;
            timer = setTimeout(function () { timer = null; scanDom(); }, 800);
        });
        try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {}

        setInterval(scanPerf, 3000);
        scanAll();
        document.addEventListener('DOMContentLoaded', scanAll);
        window.addEventListener('load', scanAll);
        })();
        """#
    }
}
