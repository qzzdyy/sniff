import Foundation
import WebKit

/// 接收网页 JS 发来的嗅探消息
final class SniffMessageHandler: NSObject, WKScriptMessageHandler {
    private let store: ResourceStore

    init(store: ResourceStore) {
        self.store = store
    }

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.name == "sniff",
              let body = message.body as? [String: Any],
              let urlString = body["url"] as? String,
              let url = URL(string: urlString) else { return }
        store.add(url: url, mime: body["type"] as? String,
                  pageURL: message.webView?.url)
    }
}
