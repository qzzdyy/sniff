import Foundation
import WebKit

/// 持有 WKWebView 引用，供 SwiftUI 工具栏发号施令
final class WebViewStore: ObservableObject {
    weak var webView: WKWebView?
    @Published var currentURL: URL?
    @Published var pageTitle: String = ""
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false

    func goBack()    { webView?.goBack() }
    func goForward() { webView?.goForward() }
    func reload()    { webView?.reload() }
    func stop()      { webView?.stopLoading() }

    func load(_ text: String) {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return }
        if !s.contains(".") || s.contains(" ") {
            // 当成搜索词
            let q = s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s
            s = "https://www.baidu.com/s?wd=\(q)"
        } else if !s.lowercased().hasPrefix("http") {
            s = "https://" + s
        }
        guard let url = URL(string: s) else { return }
        webView?.load(URLRequest(url: url))
    }

    func refreshNavState() {
        guard let wv = webView else { return }
        canGoBack = wv.canGoBack
        canGoForward = wv.canGoForward
        isLoading = wv.isLoading
        currentURL = wv.url
        pageTitle = wv.title ?? ""
    }
}
