import SwiftUI
import WebKit

/// SwiftUI 包装的 WKWebView：注册嗅探 scheme handler + 注入嗅探脚本
struct SniffWebView: UIViewRepresentable {
    @ObservedObject var webViewStore: WebViewStore
    @ObservedObject var resourceStore: ResourceStore

    func makeCoordinator() -> Coordinator {
        Coordinator(webViewStore: webViewStore)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()

        // 1. JS 消息通道 + 嗅探脚本（document start 注入，抢在页面脚本前）
        //    注意：http/https 是 WebKit 内置 scheme，不能注册 WKURLSchemeHandler，
        //    否则 setURLSchemeHandler 会抛 NSInvalidArgumentException 直接闪退。
        let content = WKUserContentController()
        content.add(SniffMessageHandler(store: resourceStore), name: "sniff")
        content.addUserScript(WKUserScript(source: SniffScript.source(),
                                           injectionTime: .atDocumentStart,
                                           forMainFrameOnly: false))
        config.userContentController = content

        // 2. 网页属性
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webViewStore.webView = webView

        let home = URL(string: "https://www.baidu.com")!
        webView.load(URLRequest(url: home))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    // MARK: - Coordinator

    class Coordinator: NSObject, WKNavigationDelegate {
        let webViewStore: WebViewStore

        init(webViewStore: WebViewStore) {
            self.webViewStore = webViewStore
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            webViewStore.isLoading = true
            webViewStore.refreshNavState()
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webViewStore.isLoading = false
            webViewStore.refreshNavState()
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            webViewStore.isLoading = false
            webViewStore.refreshNavState()
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // 非 http/https 的 scheme（微信/淘宝/App 跳转等）放行给系统
            if let url = navigationAction.request.url,
               let scheme = url.scheme?.lowercased(),
               !["http", "https", "about", "blob"].contains(scheme) {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
