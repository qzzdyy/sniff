import Foundation

/// 嗅探到的一条媒体资源
struct ResourceItem: Identifiable, Equatable, Hashable {
    enum Kind: String, CaseIterable {
        case video
        case audio
        case image
        case hls      // m3u8 播放列表（不直接下载，捕获链接）
        case live     // 实况照片/其他
        var title: String {
            switch self {
            case .video: return "视频"
            case .audio: return "音频"
            case .image: return "图片"
            case .hls:   return "HLS"
            case .live:  return "其他"
            }
        }
        var symbol: String {
            switch self {
            case .video: return "video.fill"
            case .audio: return "waveform"
            case .image: return "photo.fill"
            case .hls:   return "list.bullet.rectangle"
            case .live:  return "paperclip"
            }
        }
    }

    let id = UUID()
    let url: URL
    var kind: Kind
    var mime: String?
    var contentLength: Int64?
    var pageURL: URL?
    var pageTitle: String?
    let date: Date = Date()

    var displayName: String {
        let name = url.lastPathComponent
        return name.isEmpty ? url.host ?? "未命名资源" : name
    }

    var sizeText: String? {
        guard let bytes = contentLength, bytes > 0 else { return nil }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    static func == (lhs: ResourceItem, rhs: ResourceItem) -> Bool {
        lhs.url.absoluteString == rhs.url.absoluteString
    }
    func hash(into hasher: inout Hasher) {
        hasher.combine(url.absoluteString)
    }
}
