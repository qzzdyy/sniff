import SwiftUI

@main
struct SniffApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
