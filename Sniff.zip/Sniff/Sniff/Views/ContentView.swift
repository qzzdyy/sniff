import SwiftUI

/// 轻量分享面板封装
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct ContentView: View {
    @StateObject private var webViewStore = WebViewStore()
    @StateObject private var resourceStore = ResourceStore()
    @StateObject private var downloadManager = DownloadManager()

    private let accent = Color(red: 0.11, green: 0.11, blue: 0.12)

    var body: some View {
        TabView {
            BrowserView(webViewStore: webViewStore,
                        resourceStore: resourceStore,
                        downloadManager: downloadManager)
                .tabItem { Label("浏览", systemImage: "safari") }

            DownloadsView(downloadManager: downloadManager)
                .tabItem { Label("下载", systemImage: "arrow.down.circle") }

            SettingsView(webViewStore: webViewStore, resourceStore: resourceStore)
                .tabItem { Label("设置", systemImage: "gearshape") }
        }
        .tint(accent)
    }
}

#Preview {
    ContentView()
}
