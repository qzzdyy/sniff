import SwiftUI

/// 轻量分享面板封装
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct ContentView: View {
    @StateObject private var webViewStore = WebViewStore()
    @StateObject private var resourceStore = ResourceStore()
    @StateObject private var downloadManager = DownloadManager()

    @State private var addressText = ""
    @State private var showResources = false
    @State private var showDesktopUA = false
    @State private var toast: String?

    private let accent = Color(red: 0.11, green: 0.11, blue: 0.12) // #1C1C1F 近黑

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            VStack(spacing: 0) {
                addressBar
                toolbar
                Divider()
                SniffWebView(webViewStore: webViewStore, resourceStore: resourceStore)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }

            // 轻提示
            if let toast {
                VStack {
                    Spacer()
                    Text(toast)
                        .font(.footnote)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(Capsule().fill(Color.black.opacity(0.82)))
                        .padding(.bottom, 28)
                }
                .transition(.opacity.combined(with: .move(edge: .bottom)))
                .animation(.easeInOut(duration: 0.2), value: toast)
            }
        }
        .sheet(isPresented: $showResources, onDismiss: { resourceStore.resetBadge() }) {
            ResourceListView(resourceStore: resourceStore, downloadManager: downloadManager)
        }
        .onAppear { addressText = "https://www.baidu.com" }
    }

    // MARK: - 地址栏

    private var addressBar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 6) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(Color(white: 0.45))
                TextField("输入网址或搜索内容", text: $addressText)
                    .font(.system(size: 15))
                    .disableAutocorrection(true)
                    .keyboardType(.URL)
                    .submitLabel(.go)
                    .onSubmit { webViewStore.load(addressText) }
            }
            .padding(.horizontal, 12)
            .frame(height: 38)
            .background(Color(red: 0.96, green: 0.96, blue: 0.97))
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            // 嗅探结果入口
            Button {
                showResources = true
            } label: {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "dot.radiowaves.left.and.right")
                        .font(.system(size: 17, weight: .medium))
                        .frame(width: 34, height: 34)
                        .foregroundColor(accent)
                    if resourceStore.newCount > 0 {
                        Text("\(min(resourceStore.newCount, 99))")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.red))
                            .offset(x: 6, y: -6)
                    }
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.top, 8)
    }

    // MARK: - 工具栏

    private var toolbar: some View {
        HStack(spacing: 0) {
            toolButton("chevron.backward", enabled: webViewStore.canGoBack) { webViewStore.goBack() }
            toolButton("chevron.forward", enabled: webViewStore.canGoForward) { webViewStore.goForward() }
            toolButton(webViewStore.isLoading ? "xmark" : "arrow.clockwise", enabled: true) {
                webViewStore.isLoading ? webViewStore.stop() : webViewStore.reload()
            }
            toolButton("house") { webViewStore.load("https://www.baidu.com") }
            toolButton(showDesktopUA ? "desktopcomputer" : "iphone") {
                showDesktopUA.toggle()
                webViewStore.webView?.customUserAgent = showDesktopUA
                    ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
                    : "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
                webViewStore.reload()
                showToast(showDesktopUA ? "已切换桌面版 UA" : "已切换移动版 UA")
            }
            Spacer()
            Text(webViewStore.currentURL?.host ?? "")
                .font(.caption)
                .foregroundColor(Color(white: 0.55))
                .lineLimit(1)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .background(Color(white: 0.985))
    }

    private func toolButton(_ symbol: String, enabled: Bool = true, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(enabled ? accent : Color(white: 0.75))
                .frame(width: 44, height: 36)
        }
        .disabled(!enabled)
    }

    private func showToast(_ text: String) {
        toast = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { toast = nil }
    }
}

#Preview {
    ContentView()
}
