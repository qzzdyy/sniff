import SwiftUI
import UIKit
import AVKit

/// 全屏预览：视频用 AVPlayer（支持 m3u8 直接播放），图片用异步加载查看
struct PreviewSheet: View {
    let item: ResourceItem
    @Environment(\.dismiss) private var dismiss

    @State private var player: AVPlayer?
    @State private var image: UIImage?

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                content
            }
            .navigationTitle(item.displayName)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("完成") { dismiss() }.foregroundColor(.white)
                }
            }
            .toolbarBackground(.black, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
        .onAppear(perform: load)
        .onDisappear { player?.pause() }
    }

    @ViewBuilder
    private var content: some View {
        if item.kind == .image {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
            } else {
                ProgressView().tint(.white)
            }
        } else {
            if let player {
                VideoPlayer(player: player)
                    .ignoresSafeArea(edges: .bottom)
            } else {
                ProgressView().tint(.white)
            }
        }
    }

    private func load() {
        guard player == nil, image == nil else { return }
        if item.kind == .image {
            URLSession.shared.dataTask(with: item.url) { data, _, _ in
                guard let data, let img = UIImage(data: data) else { return }
                DispatchQueue.main.async { image = img }
            }.resume()
        } else {
            let p = AVPlayer(url: item.url)
            player = p
            p.play()
        }
    }
}
