import SwiftUI
import UIKit

/// 嗅探资源列表：缩略图 + 分类筛选 + 预览 + 下载
struct ResourceListView: View {
    @ObservedObject var resourceStore: ResourceStore
    @ObservedObject var downloadManager: DownloadManager
    @Environment(\.dismiss) private var dismiss

    @State private var filter: ResourceItem.Kind?
    @State private var activeSheet: ActiveSheet?
    @State private var toast: String?

    private let accent = Color(red: 0.11, green: 0.11, blue: 0.12)

    private enum ActiveSheet: Identifiable {
        case preview(ResourceItem)
        case share([Any])

        var id: String {
            switch self {
            case .preview(let item): return item.id.uuidString
            case .share: return "share"
            }
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                filterBar
                if resourceStore.items.isEmpty {
                    emptyState
                } else {
                    list
                }
            }
            .navigationTitle("嗅探到的资源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("关闭") { dismiss() }.foregroundColor(accent)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    if !resourceStore.items.isEmpty {
                        Button("清空") { resourceStore.clear() }.foregroundColor(.red)
                    }
                }
            }
            .toolbarBackground(Color.white, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .preview(let item):
                PreviewSheet(item: item)
            case .share(let items):
                ShareSheet(items: items)
            }
        }
        .overlay(alignment: .bottom) {
            if let toast {
                Text(toast)
                    .font(.footnote)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color.black.opacity(0.82)))
                    .padding(.bottom, 24)
            }
        }
    }

    // MARK: - 筛选条

    private var filteredItems: [ResourceItem] {
        guard let filter else { return resourceStore.items }
        return resourceStore.items.filter { $0.kind == filter }
    }

    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip(title: "全部", count: resourceStore.items.count, active: filter == nil) { filter = nil }
                ForEach(ResourceItem.Kind.allCases, id: \.self) { kind in
                    let n = resourceStore.items.filter { $0.kind == kind }.count
                    if n > 0 {
                        chip(title: kind.title, count: n, active: filter == kind) { filter = kind }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .background(Color(white: 0.985))
    }

    private func chip(title: String, count: Int, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(title).font(.system(size: 13, weight: .medium))
                Text("\(count)")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(active ? .black.opacity(0.55) : .white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 1.5)
                    .background(Capsule().fill(active ? Color.white : Color.black.opacity(0.12)))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(active ? Color(red: 0.93, green: 0.93, blue: 0.95) : Color.white))
            .foregroundColor(active ? accent : Color(white: 0.4))
            .overlay(Capsule().stroke(Color(white: 0.88), lineWidth: active ? 0 : 1))
        }
        .buttonStyle(.plain)
    }

    // MARK: - 列表

    private var list: some View {
        List {
            ForEach(filteredItems) { item in
                row(item)
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
            }
        }
        .listStyle(.plain)
    }

    private func row(_ item: ResourceItem) -> some View {
        let task = downloadManager.task(for: item)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                thumb(item)
                    .frame(width: 54, height: 54)
                    .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))

                VStack(alignment: .leading, spacing: 3) {
                    Text(item.displayName)
                        .font(.system(size: 14, weight: .medium))
                        .lineLimit(1)
                    HStack(spacing: 6) {
                        Text(item.kind.title)
                            .font(.system(size: 11, weight: .semibold))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1.5)
                            .background(Capsule().fill(Color(white: 0.93)))
                            .foregroundColor(Color(white: 0.35))
                        if let size = item.sizeText {
                            Text(size).font(.system(size: 11)).foregroundColor(Color(white: 0.5))
                        }
                        Text(item.url.host ?? "")
                            .font(.system(size: 11))
                            .foregroundColor(Color(white: 0.55))
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 6)
                actionButton(item, task: task)
            }

            if let task {
                taskStatus(task, item: item)
            }
        }
        .padding(12)
        .background(Color(white: 0.985))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .contentShape(Rectangle())
        .onTapGesture { activeSheet = .preview(item) }
    }

    @ViewBuilder
    private func thumb(_ item: ResourceItem) -> some View {
        if item.kind == .image {
            AsyncImage(url: item.url) { phase in
                if let image = phase.image {
                    image.resizable().scaledToFill()
                } else {
                    thumbPlaceholder(item.kind)
                }
            }
        } else {
            VideoThumb(url: item.url, symbol: item.kind.symbol)
        }
    }

    private func thumbPlaceholder(_ kind: ResourceItem.Kind) -> some View {
        ZStack {
            Color(white: 0.93)
            Image(systemName: kind.symbol)
                .font(.system(size: 18))
                .foregroundColor(Color(white: 0.45))
        }
    }

    @ViewBuilder
    private func actionButton(_ item: ResourceItem, task: DownloadTask?) -> some View {
        if let task, case .done = task.status {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 22))
                .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.14))
        } else if let task, case .running = task.status {
            Text("\(Int(task.progress * 100))%")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(accent)
                .frame(width: 44)
        } else {
            Button {
                downloadManager.download(item)
                showToast("开始下载：\(item.displayName)")
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "arrow.down.circle").font(.system(size: 13, weight: .medium))
                    Text(item.kind == .hls ? "缓存" : "下载").font(.system(size: 13, weight: .medium))
                }
                .foregroundColor(accent)
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private func taskStatus(_ task: DownloadTask, item: ResourceItem) -> some View {
        switch task.status {
        case .running:
            ProgressView(value: min(max(task.progress, 0), 1))
                .progressViewStyle(.linear)
                .tint(accent)
        case .done:
            HStack(spacing: 18) {
                Button {
                    guard let local = task.localURL else { return }
                    if item.kind == .image {
                        downloadManager.saveImageToAlbum(local) { r in showResult(r) }
                    } else {
                        downloadManager.saveVideoToAlbum(local) { r in showResult(r) }
                    }
                } label: {
                    label("相册", symbol: "square.and.arrow.down")
                }
                .buttonStyle(.plain)

                Button {
                    if let local = task.localURL { activeSheet = .share([local]) }
                } label: {
                    label("分享", symbol: "square.and.arrow.up")
                }
                .buttonStyle(.plain)

                Spacer()

                Button {
                    downloadManager.remove(task)
                } label: {
                    label("移除", symbol: "trash")
                }
                .buttonStyle(.plain)
            }
        case .failed(let msg):
            HStack(spacing: 12) {
                Text(msg)
                    .font(.caption)
                    .foregroundColor(.red)
                    .lineLimit(2)
                Spacer()
                Button("重试") { downloadManager.retry(task) }
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(accent)
            }
        }
    }

    private func label(_ text: String, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 13, weight: .medium))
            Text(text).font(.system(size: 13, weight: .medium))
        }
        .foregroundColor(accent)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "dot.radiowaves.left.and.right")
                .font(.system(size: 40, weight: .light))
                .foregroundColor(Color(white: 0.75))
            Text("还没有嗅探到资源")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(white: 0.35))
            Text("打开网页、点一下视频播放，\n图片 / 视频 / m3u8 会自动收集到这里")
                .font(.system(size: 13))
                .foregroundColor(Color(white: 0.55))
                .multilineTextAlignment(.center)
            Spacer()
        }
    }

    private func showResult(_ result: Result<Void, Error>) {
        switch result {
        case .success: showToast("已保存到相册")
        case .failure(let e): showToast(e.localizedDescription)
        }
    }

    private func showToast(_ text: String) {
        withAnimation { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation { toast = nil }
        }
    }
}

/// 视频缩略图（异步抽帧）
struct VideoThumb: View {
    let url: URL
    let symbol: String
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            Color(white: 0.93)
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: symbol)
                    .font(.system(size: 18))
                    .foregroundColor(Color(white: 0.45))
            }
        }
        .clipped()
        .onAppear {
            if let cached = ThumbnailLoader.shared.cached(for: url) {
                image = cached
                return
            }
            ThumbnailLoader.shared.image(for: url) { img in
                if let img { image = img }
            }
        }
    }
}
