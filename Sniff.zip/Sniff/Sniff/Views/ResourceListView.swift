import SwiftUI
import UIKit

/// 嗅探资源列表面板
struct ResourceListView: View {
    @ObservedObject var resourceStore: ResourceStore
    @ObservedObject var downloadManager: DownloadManager
    @Environment(\.dismiss) private var dismiss

    @State private var filter: ResourceItem.Kind?
    @State private var toast: String?
    @State private var shareItems: [Any] = []

    var body: some View {
        NavigationStack {
            Group {
                if resourceStore.items.isEmpty {
                    emptyState
                } else {
                    list
                }
            }
            .navigationTitle("嗅探到的资源")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("关闭") { dismiss() }
                        .foregroundColor(Color(red: 0.11, green: 0.11, blue: 0.12))
                }
                ToolbarItem(placement: .topBarTrailing) {
                    if !resourceStore.items.isEmpty {
                        Button("清空") { resourceStore.clear() }
                            .foregroundColor(.red)
                    }
                }
            }
            .toolbarBackground(Color.white, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .overlay(alignment: .bottom) {
                if let toast {
                    Text(toast)
                        .font(.footnote)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(Capsule().fill(Color.black.opacity(0.82)))
                        .padding(.bottom, 20)
                }
            }
        }
        .sheet(isPresented: Binding(get: { !shareItems.isEmpty },
                                    set: { if !$0 { shareItems = [] } })) {
            ShareSheet(items: shareItems)
        }
    }

    // MARK: - 列表

    private var list: some View {
        VStack(spacing: 0) {
            filterBar
            List {
                ForEach(filteredItems) { item in
                    row(item)
                        .listRowSeparator(.hidden)
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                }
            }
            .listStyle(.plain)
        }
    }

    private var filteredItems: [ResourceItem] {
        guard let filter else { return resourceStore.items }
        return resourceStore.items.filter { $0.kind == filter }
    }

    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip(title: "全部", count: resourceStore.items.count, active: filter == nil) { filter = nil }
                ForEach(ResourceItem.Kind.allCases, id: \.self) { kind in
                    let n = resourceStore.items.filter { $0.kind == kind }.count
                    if n > 0 {
                        chip(title: kind.title, count: n, active: filter == kind) { filter = kind }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .background(Color(white: 0.985))
    }

    private func chip(title: String, count: Int, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(title).font(.system(size: 13, weight: .medium))
                Text("\(count)")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(active ? .black.opacity(0.55) : .white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 1.5)
                    .background(Capsule().fill(active ? Color.white : Color.black.opacity(0.12)))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(active ? Color(red: 0.93, green: 0.93, blue: 0.95) : Color.white))
            .foregroundColor(active ? Color(red: 0.11, green: 0.11, blue: 0.12) : Color(white: 0.4))
            .overlay(Capsule().stroke(Color(white: 0.88), lineWidth: active ? 0 : 1))
        }
        .buttonStyle(.plain)
    }

    private func row(_ item: ResourceItem) -> some View {
        let task = downloadManager.tasks.first { $0.item == item }
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: item.kind.symbol)
                    .font(.system(size: 15))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(RoundedRectangle(cornerRadius: 9, style: .continuous).fill(Color(red: 0.13, green: 0.13, blue: 0.14)))

                VStack(alignment: .leading, spacing: 3) {
                    Text(item.displayName)
                        .font(.system(size: 14, weight: .medium))
                        .lineLimit(1)
                    HStack(spacing: 6) {
                        Text(item.kind.title)
                            .font(.system(size: 11, weight: .semibold))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1.5)
                            .background(Capsule().fill(Color(white: 0.93)))
                            .foregroundColor(Color(white: 0.35))
                        if let size = item.sizeText {
                            Text(size).font(.system(size: 11)).foregroundColor(Color(white: 0.5))
                        }
                        Text(item.url.host ?? "")
                            .font(.system(size: 11))
                            .foregroundColor(Color(white: 0.55))
                            .lineLimit(1)
                    }
                }
                Spacer()
                actionButton(item, task: task)
            }

            // 下载进度 / 完成后操作
            if let task {
                if case .running = task.status {
                    ProgressView(value: task.progress)
                        .progressViewStyle(.linear)
                        .tint(Color(red: 0.11, green: 0.11, blue: 0.12))
                } else if case .done = task.status, let local = task.localURL {
                    HStack(spacing: 16) {
                        Button {
                            if item.kind == .video {
                                downloadManager.saveVideoToAlbum(local) { r in show(r, ok: "已保存到相册") }
                            } else if item.kind == .image {
                                downloadManager.saveImageToAlbum(local) { r in show(r, ok: "已保存到相册") }
                            }
                        } label: {
                            label("相册", symbol: "square.and.arrow.down")
                        }
                        .buttonStyle(.plain)

                        Button { shareItems = [local] } label: {
                            label("分享", symbol: "square.and.arrow.up")
                        }
                        .buttonStyle(.plain)

                        Spacer()
                        Button { downloadManager.remove(task) } label: {
                            label("移除", symbol: "trash")
                        }
                        .buttonStyle(.plain)
                    }
                    .font(.system(size: 13))
                    .foregroundColor(Color(red: 0.11, green: 0.11, blue: 0.12))
                } else if case .failed(let msg) = task.status {
                    Text(msg)
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
        }
        .padding(12)
        .background(Color(white: 0.985))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    @ViewBuilder
    private func actionButton(_ item: ResourceItem, task: DownloadTask?) -> some View {
        if let task, case .done = task.status {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 22))
                .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.14))
        } else if item.kind == .hls {
            Button {
                UIPasteboard.general.string = item.url.absoluteString
                showToast("链接已复制，m3u8 需配合其他工具下载")
            } label: {
                label("复制", symbol: "doc.on.doc")
            }
            .buttonStyle(.plain)
        } else {
            Button {
                downloadManager.download(item)
                showToast("开始下载：\(item.displayName)")
            } label: {
                label("下载", symbol: "arrow.down.circle")
            }
            .buttonStyle(.plain)
        }
    }

    private func label(_ text: String, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 13, weight: .medium))
            Text(text).font(.system(size: 13, weight: .medium))
        }
        .foregroundColor(Color(red: 0.11, green: 0.11, blue: 0.12))
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "dot.radiowaves.left.and.right")
                .font(.system(size: 40, weight: .light))
                .foregroundColor(Color(white: 0.75))
            Text("还没有嗅探到资源")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(white: 0.35))
            Text("在内置浏览器中打开任意网页，\n图片、音视频、m3u8 会被自动收集到这里")
                .font(.system(size: 13))
                .foregroundColor(Color(white: 0.55))
                .multilineTextAlignment(.center)
            Spacer()
        }
    }

    private func show(_ result: Result<Void, Error>, ok: String) {
        switch result {
        case .success: showToast(ok)
        case .failure(let e): showToast(e.localizedDescription)
        }
    }

    private func showToast(_ text: String) {
        withAnimation { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation { toast = nil }
        }
    }
}
