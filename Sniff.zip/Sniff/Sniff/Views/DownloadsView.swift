import SwiftUI
import UIKit

/// 下载页：实时进度 + 完成后保存/分享/删除
struct DownloadsView: View {
    @ObservedObject var downloadManager: DownloadManager

    @State private var shareItems: [Any] = []
    @State private var previewItem: ResourceItem?

    private let accent = Color(red: 0.11, green: 0.11, blue: 0.12)

    var body: some View {
        NavigationStack {
            Group {
                if downloadManager.tasks.isEmpty {
                    emptyState
                } else {
                    List {
                        ForEach(downloadManager.tasks) { task in
                            row(task)
                                .listRowSeparator(.hidden)
                                .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("下载")
            .navigationBarTitleDisplayMode(.large)
        }
        .sheet(isPresented: Binding(get: { !shareItems.isEmpty },
                                    set: { if !$0 { shareItems = [] } })) {
            ShareSheet(items: shareItems)
        }
        .sheet(item: $previewItem) { item in
            PreviewSheet(item: item)
        }
    }

    private func row(_ task: DownloadTask) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Color(red: 0.13, green: 0.13, blue: 0.14))
                    Image(systemName: task.item.kind.symbol)
                        .font(.system(size: 15))
                        .foregroundColor(.white)
                }
                .frame(width: 40, height: 40)

                VStack(alignment: .leading, spacing: 3) {
                    Text(task.item.displayName)
                        .font(.system(size: 14, weight: .medium))
                        .lineLimit(1)
                    Text(statusText(task))
                        .font(.system(size: 11))
                        .foregroundColor(statusColor(task))
                        .lineLimit(1)
                }
                Spacer()
                trailingAction(task)
            }

            if task.isRunning {
                ProgressView(value: min(max(task.progress, 0), 1))
                    .progressViewStyle(.linear)
                    .tint(accent)
            }

            if case .done = task.status {
                HStack(spacing: 18) {
                    Button {
                        if let local = task.localURL { saveToAlbum(task, local: local) }
                    } label: {
                        label("相册", symbol: "square.and.arrow.down")
                    }
                    .buttonStyle(.plain)

                    Button {
                        if let local = task.localURL { shareItems = [local] }
                    } label: {
                        label("分享", symbol: "square.and.arrow.up")
                    }
                    .buttonStyle(.plain)

                    Button {
                        previewItem = task.item
                    } label: {
                        label("播放", symbol: "play.circle")
                    }
                    .buttonStyle(.plain)

                    Spacer()

                    Button {
                        downloadManager.remove(task)
                    } label: {
                        label("删除", symbol: "trash")
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(12)
        .background(Color(white: 0.985))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    @ViewBuilder
    private func trailingAction(_ task: DownloadTask) -> some View {
        switch task.status {
        case .running:
            Text("\(Int(task.progress * 100))%")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(accent)
        case .done:
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 22))
                .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.14))
        case .failed:
            Button("重试") { downloadManager.retry(task) }
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(accent)
        }
    }

    private func statusText(_ task: DownloadTask) -> String {
        switch task.status {
        case .running:
            return task.item.kind == .hls ? "m3u8 合成中…" : "下载中…"
        case .done:
            return "已完成"
        case .failed(let msg):
            return msg
        }
    }

    private func statusColor(_ task: DownloadTask) -> Color {
        if case .failed = task.status { return .red }
        return Color(white: 0.5)
    }

    private func label(_ text: String, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 13, weight: .medium))
            Text(text).font(.system(size: 13, weight: .medium))
        }
        .foregroundColor(accent)
    }

    private func saveToAlbum(_ task: DownloadTask, local: URL) {
        if task.item.kind == .image {
            downloadManager.saveImageToAlbum(local) { _ in }
        } else {
            downloadManager.saveVideoToAlbum(local) { _ in }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "arrow.down.circle")
                .font(.system(size: 40, weight: .light))
                .foregroundColor(Color(white: 0.75))
            Text("还没有下载任务")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(white: 0.35))
            Text("在浏览页点右上角嗅探按钮，\n选一个资源点「下载」")
                .font(.system(size: 13))
                .foregroundColor(Color(white: 0.55))
                .multilineTextAlignment(.center)
            Spacer()
        }
    }
}
