import SwiftUI
import UIKit

/// 下载页：实时进度、暂停/继续、滑动删除、多选批量操作
struct DownloadsView: View {
    @ObservedObject var downloadManager: DownloadManager

    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var shareItems: [Any] = []
    @State private var previewItem: ResourceItem?

    private let accent = Color(red: 0.11, green: 0.11, blue: 0.12)

    private var tasks: [DownloadTask] { downloadManager.tasks }
    private var allSelected: Bool { !tasks.isEmpty && selected.count >= tasks.count }

    var body: some View {
        NavigationStack {
            Group {
                if tasks.isEmpty {
                    emptyState
                } else {
                    list
                }
            }
            .navigationTitle(selecting ? "已选 \(selected.count) 项" : "下载")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if selecting {
                        Button(allSelected ? "取消全选" : "全选") { toggleAll() }
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    if !tasks.isEmpty {
                        Button(selecting ? "完成" : "选择") {
                            selecting.toggle()
                            if !selecting { selected.removeAll() }
                        }
                    }
                }
                if selecting {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button {
                            bulkPause()
                        } label: {
                            Label("暂停", systemImage: "pause.fill")
                        }
                        Spacer()
                        Button {
                            bulkResume()
                        } label: {
                            Label("继续", systemImage: "play.fill")
                        }
                        Spacer()
                        Button(role: .destructive) {
                            bulkDelete()
                        } label: {
                            Label("删除", systemImage: "trash")
                        }
                    }
                }
            }
        }
        .sheet(isPresented: Binding(get: { !shareItems.isEmpty },
                                    set: { if !$0 { shareItems = [] } })) {
            ShareSheet(items: shareItems)
        }
        .sheet(item: $previewItem) { item in
            PreviewSheet(item: item)
        }
    }

    // MARK: - 列表

    private var list: some View {
        List {
            ForEach(tasks) { task in
                row(task)
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button(role: .destructive) {
                            downloadManager.remove(task)
                            selected.remove(task.id)
                        } label: {
                            Label("删除", systemImage: "trash")
                        }
                    }
                    .swipeActions(edge: .leading) {
                        if task.isRunning {
                            Button {
                                downloadManager.pause(task)
                            } label: {
                                Label("暂停", systemImage: "pause")
                            }
                            .tint(.orange)
                        } else if task.isPaused {
                            Button {
                                downloadManager.resume(task)
                            } label: {
                                Label("继续", systemImage: "play")
                            }
                            .tint(.green)
                        }
                    }
            }
        }
        .listStyle(.plain)
    }

    @ViewBuilder
    private func row(_ task: DownloadTask) -> some View {
        if selecting {
            HStack(spacing: 12) {
                Image(systemName: selected.contains(task.id) ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 21))
                    .foregroundColor(selected.contains(task.id) ? accent : Color(white: 0.78))

                icon(task)
                VStack(alignment: .leading, spacing: 3) {
                    Text(task.item.displayName)
                        .font(.system(size: 14, weight: .medium))
                        .lineLimit(1)
                    Text(statusText(task))
                        .font(.system(size: 11))
                        .foregroundColor(statusColor(task))
                        .lineLimit(1)
                }
                Spacer()
            }
            .padding(12)
            .background(Color(white: 0.985))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .contentShape(Rectangle())
            .onTapGesture { toggleSelect(task.id) }
        } else {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 12) {
                    icon(task)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(task.item.displayName)
                            .font(.system(size: 14, weight: .medium))
                            .lineLimit(1)
                        Text(statusText(task))
                            .font(.system(size: 11))
                            .foregroundColor(statusColor(task))
                            .lineLimit(1)
                    }
                    Spacer()
                    trailingAction(task)
                }

                if task.isRunning || task.isPaused {
                    ProgressView(value: min(max(task.progress, 0), 1))
                        .progressViewStyle(.linear)
                        .tint(accent)
                }

                if task.isDone {
                    HStack(spacing: 18) {
                        Button {
                            if let local = task.localURL { saveToAlbum(task, local: local) }
                        } label: {
                            label("相册", symbol: "square.and.arrow.down")
                        }
                        .buttonStyle(.plain)

                        Button {
                            if let local = task.localURL { shareItems = [local] }
                        } label: {
                            label("分享", symbol: "square.and.arrow.up")
                        }
                        .buttonStyle(.plain)

                        Button {
                            previewItem = task.item
                        } label: {
                            label("播放", symbol: "play.circle")
                        }
                        .buttonStyle(.plain)

                        Spacer()

                        Button {
                            downloadManager.remove(task)
                        } label: {
                            label("删除", symbol: "trash")
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(12)
            .background(Color(white: 0.985))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    private func icon(_ task: DownloadTask) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(Color(red: 0.13, green: 0.13, blue: 0.14))
            Image(systemName: task.item.kind.symbol)
                .font(.system(size: 15))
                .foregroundColor(.white)
        }
        .frame(width: 40, height: 40)
    }

    @ViewBuilder
    private func trailingAction(_ task: DownloadTask) -> some View {
        switch task.status {
        case .running:
            Button {
                downloadManager.pause(task)
            } label: {
                Image(systemName: "pause.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(accent)
            }
            .buttonStyle(.plain)
        case .paused:
            Button {
                downloadManager.resume(task)
            } label: {
                Image(systemName: "play.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(accent)
            }
            .buttonStyle(.plain)
        case .done:
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 22))
                .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.14))
        case .failed:
            Button("重试") { downloadManager.retry(task) }
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(accent)
        }
    }

    private func statusText(_ task: DownloadTask) -> String {
        switch task.status {
        case .running:
            let pct = Int(task.progress * 100)
            return task.item.kind == .hls ? "m3u8 合成中 \(pct)%" : "\(pct)%"
        case .paused:
            return "已暂停 \(Int(task.progress * 100))%"
        case .done:
            return "已完成"
        case .failed(let msg):
            return msg
        }
    }

    private func statusColor(_ task: DownloadTask) -> Color {
        if case .failed = task.status { return .red }
        if task.isPaused { return .orange }
        return Color(white: 0.5)
    }

    private func label(_ text: String, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 13, weight: .medium))
            Text(text).font(.system(size: 13, weight: .medium))
        }
        .foregroundColor(accent)
    }

    private func saveToAlbum(_ task: DownloadTask, local: URL) {
        if task.item.kind == .image {
            downloadManager.saveImageToAlbum(local) { _ in }
        } else {
            downloadManager.saveVideoToAlbum(local) { _ in }
        }
    }

    // MARK: - 多选

    private func toggleSelect(_ id: UUID) {
        if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
    }

    private func toggleAll() {
        if allSelected {
            selected.removeAll()
        } else {
            selected = Set(tasks.map { $0.id })
        }
    }

    private func bulkPause() {
        for task in tasks where selected.contains(task.id) && task.isRunning {
            downloadManager.pause(task)
        }
    }

    private func bulkResume() {
        for task in tasks where selected.contains(task.id) && task.isPaused {
            downloadManager.resume(task)
        }
    }

    private func bulkDelete() {
        for task in tasks where selected.contains(task.id) {
            downloadManager.remove(task)
        }
        selected.removeAll()
        selecting = false
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "arrow.down.circle")
                .font(.system(size: 40, weight: .light))
                .foregroundColor(Color(white: 0.75))
            Text("还没有下载任务")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(white: 0.35))
            Text("在浏览页点右上角嗅探按钮，\n选一个资源点「下载」")
                .font(.system(size: 13))
                .foregroundColor(Color(white: 0.55))
                .multilineTextAlignment(.center)
            Spacer()
        }
    }
}
