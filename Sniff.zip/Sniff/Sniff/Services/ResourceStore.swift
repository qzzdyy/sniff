import Foundation

/// 全局资源仓库：收集各路嗅探结果并去重、分类
final class ResourceStore: ObservableObject {
    @Published private(set) var items: [ResourceItem] = []
    @Published private(set) var newCount: Int = 0

    private var seen = Set<String>()
    private let lock = NSLock()

    /// 由 JS 层上报
    /// - Parameter hint: JS 上报的来源线索（DOM 节点名 / performance.initiatorType）
    func add(url: URL, mime: String? = nil, hint: String? = nil, contentLength: Int64? = nil,
             pageURL: URL? = nil, pageTitle: String? = nil) {
        let key = url.absoluteString
        guard key.hasPrefix("http") else { return }

        // 网页本身、脚本、样式、JSON 等一律不要
        let ext = url.pathExtension.lowercased()
        if Self.ignoredExts.contains(ext) { return }

        guard let kind = Self.classify(url: url, mime: mime, hint: hint) else { return }

        lock.lock()
        let isNew = !seen.contains(key)
        if isNew { seen.insert(key) }
        lock.unlock()
        guard isNew else { return }

        let item = ResourceItem(url: url, kind: kind, mime: mime,
                                contentLength: contentLength,
                                pageURL: pageURL, pageTitle: pageTitle)
        DispatchQueue.main.async {
            self.items.insert(item, at: 0)
            self.newCount += 1
        }
    }

    func clear() {
        lock.lock()
        seen.removeAll()
        lock.unlock()
        DispatchQueue.main.async {
            self.items.removeAll()
            self.newCount = 0
        }
    }

    func resetBadge() {
        DispatchQueue.main.async { self.newCount = 0 }
    }

    var countsByKind: [ResourceItem.Kind: Int] {
        Dictionary(grouping: items, by: { $0.kind }).mapValues { $0.count }
    }

    // MARK: - 分类

    private static let videoExts: Set<String> = ["mp4", "mov", "m4v", "mkv", "webm", "avi", "flv", "3gp", "wmv"]
    private static let audioExts: Set<String> = ["mp3", "m4a", "aac", "wav", "flac", "ogg", "wma", "opus", "caf"]
    private static let imageExts: Set<String> = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg", "ico"]

    /// 明确不是媒体资源的后缀
    private static let ignoredExts: Set<String> = [
        "html", "htm", "php", "asp", "aspx", "jsp", "do", "action",
        "js", "mjs", "css", "json", "xml", "txt", "map", "woff", "woff2", "ttf",
        "ts", "m4s", "zip", "pdf"
    ]

    /// - Parameter hint: JS 侧线索：VIDEO / AUDIO / IMG / video / audio / img / net / xhr / fetch / link
    static func classify(url: URL, mime: String?, hint: String? = nil) -> ResourceItem.Kind? {
        let m = (mime ?? "").lowercased()
        let ext = url.pathExtension.lowercased()

        // 1) 自适应码流优先
        if ext == "m3u8" || ext == "mpd" || m.contains("mpegurl") || m.contains("dash+xml") {
            return .hls
        }
        // 2) MIME 明确
        if m.hasPrefix("video/") { return .video }
        if m.hasPrefix("audio/") { return .audio }
        if m.hasPrefix("image/") { return .image }
        // 3) 后缀明确
        if videoExts.contains(ext) { return .video }
        if audioExts.contains(ext) { return .audio }
        if imageExts.contains(ext) { return .image }
        // 4) 靠 JS 线索兜底
        switch (hint ?? "").lowercased() {
        case "video": return .video
        case "audio": return .audio
        case "img", "image": return .image
        default: return nil
        }
    }
}
