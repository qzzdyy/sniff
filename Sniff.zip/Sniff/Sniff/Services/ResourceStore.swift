import Foundation

/// 全局资源仓库：收集各路嗅探结果并去重
final class ResourceStore: ObservableObject {
    @Published private(set) var items: [ResourceItem] = []
    @Published private(set) var newCount: Int = 0

    private var seen = Set<String>()
    private let lock = NSLock()

    /// 由网络层（SchemeHandler）或 JS 层调用
    func add(url: URL, mime: String? = nil, contentLength: Int64? = nil,
             pageURL: URL? = nil, pageTitle: String? = nil) {
        let key = url.absoluteString
        guard !key.isEmpty, key.hasPrefix("http") else { return }

        let kind = Self.classify(url: url, mime: mime)
        // 只收媒体类资源，css/js/api 等一律忽略
        guard kind != nil else { return }
        // HLS 只收 .m3u8，ts 分片太碎不展示
        if url.pathExtension.lowercased() == "ts" { return }

        lock.lock()
        let isNew = !seen.contains(key)
        if isNew {
            seen.insert(key)
            lock.unlock()
            let item = ResourceItem(url: url, kind: kind!, mime: mime,
                                    contentLength: contentLength,
                                    pageURL: pageURL, pageTitle: pageTitle)
            DispatchQueue.main.async {
                self.items.insert(item, at: 0)
                self.newCount += 1
            }
        } else {
            lock.unlock()
        }
    }

    func clear() {
        lock.lock()
        seen.removeAll()
        lock.unlock()
        DispatchQueue.main.async {
            self.items.removeAll()
            self.newCount = 0
        }
    }

    func resetBadge() {
        DispatchQueue.main.async { self.newCount = 0 }
    }

    var countsByKind: [ResourceItem.Kind: Int] {
        Dictionary(grouping: items, by: { $0.kind }).mapValues { $0.count }
    }

    // MARK: - 分类

    private static let videoExts: Set<String> = ["mp4", "mov", "m4v", "mkv", "webm", "avi", "flv", "3gp", "wmv"]
    private static let audioExts: Set<String> = ["mp3", "m4a", "aac", "wav", "flac", "ogg", "wma", "opus", "caf"]
    private static let imageExts: Set<String> = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg", "ico"]

    static func classify(url: URL, mime: String?) -> ResourceItem.Kind? {
        let m = (mime ?? "").lowercased()
        let ext = url.pathExtension.lowercased()
        let path = url.path.lowercased()

        // m3u8 / mpd 自适应流
        if ext == "m3u8" || ext == "mpd" || m.contains("mpegurl") || m.contains("dash+xml") {
            return .hls
        }
        if m.hasPrefix("video/") { return .video }
        if m.hasPrefix("audio/") { return .audio }
        if m.hasPrefix("image/") { return .image }
        if videoExts.contains(ext) { return .video }
        if audioExts.contains(ext) { return .audio }
        if imageExts.contains(ext) { return .image }

        // 无后缀但路径带媒体关键字的兜底（如 /get_video?id=xx）
        let lowered = path + "?" + (url.query ?? "")
        if lowered.contains("video") || lowered.contains(".mp4") { return .video }
        if lowered.contains("audio") || lowered.contains(".mp3") { return .audio }
        if lowered.contains("image") || lowered.contains(".jpg") { return .image }
        return nil
    }
}
