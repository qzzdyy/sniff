import Foundation

/// 资源仓库：抓取与过滤分离（照抄 WebTaskManager 的 collected / filtered 双轨思路）
final class ResourceStore: ObservableObject {
    @Published private(set) var items: [ResourceItem] = []
    @Published private(set) var newCount: Int = 0
    @Published var filter: ResourceItem.Kind?

    private var seen = Set<String>()
    private let lock = NSLock()

    /// JS 层上报
    /// - Parameter hint: DOM 节点名或 performance.initiatorType
    func add(url: URL, mime: String? = nil, hint: String? = nil, contentLength: Int64? = nil,
             pageURL: URL? = nil, pageTitle: String? = nil) {
        let key = url.absoluteString
        guard key.hasPrefix("http") else { return }

        let ext = url.pathExtension.lowercased()
        if Self.ignoredExts.contains(ext) { return }
        guard let kind = Self.classify(url: url, mime: mime, hint: hint) else { return }

        lock.lock()
        let isNew = !seen.contains(key)
        if isNew { seen.insert(key) }
        lock.unlock()
        guard isNew else { return }

        var item = ResourceItem(url: url, kind: kind, mime: mime,
                                contentLength: contentLength,
                                pageURL: pageURL, pageTitle: pageTitle)
        item.isPreparing = (kind != .hls)

        DispatchQueue.main.async {
            self.items.insert(item, at: 0)
            self.newCount += 1
        }

        // 命中即落地 + 生成元数据（首帧/像素/时长），列表立刻有图
        MediaProbe.shared.probe(item) { [weak self] updated in
            self?.replace(updated)
        }
    }

    private func replace(_ item: ResourceItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index] = item
    }

    /// 过滤视图（UI 用）
    var filteredItems: [ResourceItem] {
        guard let filter else { return items }
        return items.filter { $0.kind == filter }
    }

    func count(of kind: ResourceItem.Kind) -> Int {
        items.filter { $0.kind == kind }.count
    }

    func clear() {
        lock.lock()
        seen.removeAll()
        lock.unlock()
        let files = items.compactMap { $0.localFile }
        DispatchQueue.main.async {
            self.items.removeAll()
            self.newCount = 0
            for file in files { try? FileManager.default.removeItem(at: file) }
        }
    }

    func resetBadge() {
        DispatchQueue.main.async { self.newCount = 0 }
    }

    // MARK: - 分类

    private static let videoExts: Set<String> = ["mp4", "mov", "m4v", "mkv", "webm", "avi", "flv", "3gp", "wmv"]
    private static let audioExts: Set<String> = ["mp3", "m4a", "aac", "wav", "flac", "ogg", "wma", "opus", "caf"]
    private static let imageExts: Set<String> = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg", "ico"]

    private static let ignoredExts: Set<String> = [
        "html", "htm", "php", "asp", "aspx", "jsp", "do", "action",
        "js", "mjs", "css", "json", "xml", "txt", "map", "woff", "woff2", "ttf",
        "ts", "m4s", "zip", "pdf"
    ]

    static func classify(url: URL, mime: String?, hint: String? = nil) -> ResourceItem.Kind? {
        let m = (mime ?? "").lowercased()
        let ext = url.pathExtension.lowercased()

        if ext == "m3u8" || ext == "mpd" || m.contains("mpegurl") || m.contains("dash+xml") {
            return .hls
        }
        if m.hasPrefix("video/") { return .video }
        if m.hasPrefix("audio/") { return .audio }
        if m.hasPrefix("image/") { return .image }
        if videoExts.contains(ext) { return .video }
        if audioExts.contains(ext) { return .audio }
        if imageExts.contains(ext) { return .image }

        switch (hint ?? "").lowercased() {
        case "video": return .video
        case "audio": return .audio
        case "img", "image": return .image
        default: return nil
        }
    }
}
