import Foundation
import AVFoundation
import CommonCrypto

/// HLS（m3u8）下载器：
/// 1. 读主播放列表，选最高码率子列表
/// 2. 解析分片与 EXT-X-KEY（AES-128）
/// 3. 多分片并发下载（设置里可调并发数 / 限速）、失败重试并降级请求头
/// 4. 按顺序拼接成 .ts，再本地转封装为 MP4
final class HLSDownloader {

    enum HLError: LocalizedError {
        case requestFailed(Int)
        case segmentFailed(Int, Int, Int)
        case badPlaylist
        case noSegments
        case decryptFailed
        case remuxFailed
        case cancelled

        var errorDescription: String? {
            switch self {
            case .requestFailed(let code):
                return code == 0 ? "无法连接服务器（网络或域名不通）" : "播放列表请求失败（HTTP \(code)）"
            case .segmentFailed(let index, let total, let code):
                return "第 \(index)/\(total) 片失败（HTTP \(code)）"
            case .badPlaylist:    return "m3u8 解析失败"
            case .noSegments:     return "播放列表里没有分片"
            case .decryptFailed:  return "分片解密失败"
            case .remuxFailed:    return "分片已下载，但转 MP4 失败"
            case .cancelled:      return "已取消"
            }
        }
    }

    private struct Segment {
        let url: URL
        let keyURL: URL?
        let iv: Data?
    }

    private enum FetchMode {
        case full
        case noReferer
        case plain
    }

    private let referer: String
    private let userAgent: String
    private let workDir: URL
    private var session: URLSession!
    private var cancelled = false
    private var paused = false
    private let lock = NSLock()
    private var keyCache: [String: Data] = [:]
    private let keyLock = NSLock()

    init(referer: String, userAgent: String, workDir: URL) {
        self.referer = referer
        self.userAgent = userAgent
        self.workDir = workDir
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 600
        cfg.httpMaximumConnectionsPerHost = 8
        cfg.httpShouldSetCookies = true
        cfg.httpCookieStorage = HTTPCookieStorage.shared
        session = URLSession(configuration: cfg)
    }

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
        session.invalidateAndCancel()
    }

    func pause() {
        lock.lock(); paused = true; lock.unlock()
    }

    func resume() {
        lock.lock(); paused = false; lock.unlock()
    }

    private var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    private var isPaused: Bool {
        lock.lock(); defer { lock.unlock() }
        return paused
    }

    // MARK: - 入口

    func run(playlistURL: URL,
             progress: @escaping (Double) -> Void,
             completion: @escaping (Result<URL, Error>) -> Void) {
        DispatchQueue.global(qos: .utility).async {
            let result = self.work(playlistURL: playlistURL, progress: progress)
            DispatchQueue.main.async { completion(result) }
        }
    }

    // MARK: - 主流程

    private func work(playlistURL: URL, progress: @escaping (Double) -> Void) -> Result<URL, Error> {
        guard var text = fetchText(playlistURL) else { return .failure(HLError.requestFailed(0)) }
        var base = playlistURL

        if text.contains("#EXT-X-STREAM-INF") {
            guard let variant = bestVariant(in: text, base: playlistURL),
                  let sub = fetchText(variant) else { return .failure(HLError.badPlaylist) }
            base = variant
            text = sub
        }

        let segments = parseSegments(text, base: base)
        guard !segments.isEmpty else { return .failure(HLError.noSegments) }

        let total = segments.count
        let tmpDir = workDir.appendingPathComponent("hls_\(UUID().uuidString)", isDirectory: true)
        try? FileManager.default.createDirectory(at: tmpDir, withIntermediateDirectories: true)

        let concurrency = DownloadSettings.maxConcurrent
        let stateLock = NSLock()
        var completed = 0
        var firstError: Error?

        let queue = DispatchQueue(label: "sniff.hls.segments", qos: .utility, attributes: .concurrent)
        let sem = DispatchSemaphore(value: concurrency)
        let group = DispatchGroup()

        for (index, seg) in segments.enumerated() {
            sem.wait()

            stateLock.lock()
            let stop = (firstError != nil) || cancelled
            stateLock.unlock()
            if stop {
                sem.signal()
                break
            }

            group.enter()
            queue.async { [weak self] in
                defer { sem.signal(); group.leave() }
                guard let self else { return }

                // 暂停时挂起，不占连接
                while self.isPaused && !self.isCancelled {
                    Thread.sleep(forTimeInterval: 0.2)
                }
                if self.isCancelled { return }

                let fetched = self.fetchWithRetry(seg.url, isSegment: true, index: index, total: total)
                var data: Data
                switch fetched {
                case .success(let d):
                    data = d
                case .failure(let error):
                    stateLock.lock()
                    if firstError == nil { firstError = error }
                    stateLock.unlock()
                    return
                }

                if let keyURL = seg.keyURL {
                    guard let keyData = self.key(for: keyURL) else {
                        stateLock.lock()
                        if firstError == nil { firstError = HLError.decryptFailed }
                        stateLock.unlock()
                        return
                    }
                    guard let plain = Self.aes128Decrypt(data, key: keyData,
                                                         iv: seg.iv ?? Self.sequenceIV(index)) else {
                        stateLock.lock()
                        if firstError == nil { firstError = HLError.decryptFailed }
                        stateLock.unlock()
                        return
                    }
                    data = plain
                }

                let partURL = tmpDir.appendingPathComponent(String(format: "%05d.part", index))
                try? data.write(to: partURL)

                BandwidthLimiter.shared.consume(data.count)

                stateLock.lock()
                completed += 1
                let p = Double(completed) / Double(total)
                stateLock.unlock()
                progress(p)
            }
        }
        group.wait()

        stateLock.lock()
        let error = firstError
        let done = completed
        stateLock.unlock()

        if let error {
            try? FileManager.default.removeItem(at: tmpDir)
            return .failure(error)
        }
        if isCancelled {
            try? FileManager.default.removeItem(at: tmpDir)
            return .failure(HLError.cancelled)
        }
        if done < total {
            try? FileManager.default.removeItem(at: tmpDir)
            return .failure(HLError.segmentFailed(done + 1, total, 0))
        }

        // 按顺序拼成 TS
        let tsURL = workDir.appendingPathComponent("hls_\(UUID().uuidString).ts")
        FileManager.default.createFile(atPath: tsURL.path, contents: nil)
        guard let output = try? FileHandle(forWritingTo: tsURL) else {
            try? FileManager.default.removeItem(at: tmpDir)
            return .failure(HLError.badPlaylist)
        }
        for i in 0..<total {
            let partURL = tmpDir.appendingPathComponent(String(format: "%05d.part", i))
            if let data = try? Data(contentsOf: partURL) {
                output.write(data)
            }
        }
        try? output.close()
        try? FileManager.default.removeItem(at: tmpDir)

        if let mp4 = remux(from: tsURL, toBase: tsURL.deletingPathExtension()) {
            try? FileManager.default.removeItem(at: tsURL)
            return .success(mp4)
        }
        // 转封装失败也保留 TS：AVPlayer 能直接播，只是不能存相册
        return .success(tsURL)
    }

    private func key(for url: URL) -> Data? {
        let key = url.absoluteString
        keyLock.lock()
        let cached = keyCache[key]
        keyLock.unlock()
        if let cached { return cached }

        guard case .success(let data) = fetchWithRetry(url) else { return nil }
        keyLock.lock()
        keyCache[key] = data
        keyLock.unlock()
        return data
    }

    // MARK: - m3u8 解析

    private func bestVariant(in text: String, base: URL) -> URL? {
        let lines = text.components(separatedBy: "\n").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        var best: (bw: Int, url: URL)?
        for (i, line) in lines.enumerated() {
            guard line.hasPrefix("#EXT-X-STREAM-INF") else { continue }
            let attrs = attributes(line)
            let bw = Int(attrs["BANDWIDTH"] ?? "0") ?? 0
            var j = i + 1
            while j < lines.count && (lines[j].isEmpty || lines[j].hasPrefix("#")) { j += 1 }
            guard j < lines.count, let u = URL(string: lines[j], relativeTo: base)?.absoluteURL else { continue }
            if best == nil || bw > best!.bw { best = (bw, u) }
        }
        return best?.url
    }

    private func parseSegments(_ text: String, base: URL) -> [Segment] {
        var result: [Segment] = []
        var keyURL: URL?
        var iv: Data?

        for raw in text.components(separatedBy: "\n") {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty { continue }

            if line.hasPrefix("#EXT-X-KEY:") {
                let attrs = attributes(line)
                let method = (attrs["METHOD"] ?? "").uppercased()
                if method == "NONE" {
                    keyURL = nil
                    iv = nil
                } else if method == "AES-128" {
                    if let uri = attrs["URI"], let u = URL(string: uri, relativeTo: base)?.absoluteURL {
                        keyURL = u
                    }
                    if let hex = attrs["IV"] {
                        iv = Self.dataFromHex(hex)
                    }
                }
            } else if !line.hasPrefix("#") {
                guard let u = URL(string: line, relativeTo: base)?.absoluteURL else { continue }
                result.append(Segment(url: u, keyURL: keyURL, iv: iv))
            }
        }
        return result
    }

    private func attributes(_ line: String) -> [String: String] {
        guard let colon = line.firstIndex(of: ":") else { return [:] }
        let body = String(line[line.index(after: colon)...])
        var parts: [String] = []
        var current = ""
        var inQuotes = false
        for ch in body {
            if ch == "\"" {
                inQuotes.toggle()
                current.append(ch)
            } else if ch == "," && !inQuotes {
                parts.append(current)
                current = ""
            } else {
                current.append(ch)
            }
        }
        if !current.isEmpty { parts.append(current) }

        var dict: [String: String] = [:]
        for part in parts {
            let kv = part.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            guard kv.count == 2 else { continue }
            let key = String(kv[0]).trimmingCharacters(in: .whitespaces)
            let value = String(kv[1]).trimmingCharacters(in: .whitespaces)
                .replacingOccurrences(of: "\"", with: "")
            dict[key] = value
        }
        return dict
    }

    // MARK: - 网络

    private func rawFetch(_ url: URL, mode: FetchMode) -> (Data?, Int) {
        if isCancelled { return (nil, 0) }
        var data: Data?
        var status = 0
        let sem = DispatchSemaphore(value: 0)

        var req: URLRequest
        switch mode {
        case .full:
            req = MediaHeaders.request(url: url, referer: referer, userAgent: userAgent)
        case .noReferer:
            req = URLRequest(url: url)
            req.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        case .plain:
            req = URLRequest(url: url)
        }

        session.dataTask(with: req) { d, resp, _ in
            data = d
            if let http = resp as? HTTPURLResponse {
                status = http.statusCode
            } else {
                status = (d == nil) ? 0 : 200
            }
            sem.signal()
        }.resume()

        _ = sem.wait(timeout: .now() + 45)
        return (data, status)
    }

    /// 最多 4 次：完整头 → 完整头 → 只带 UA → 裸请求
    private func fetchWithRetry(_ url: URL, isSegment: Bool = false, index: Int = 0, total: Int = 0) -> Result<Data, Error> {
        let modes: [FetchMode] = [.full, .full, .noReferer, .plain]
        let delays: [TimeInterval] = [0.6, 1.5, 3.0]
        var lastStatus = 0

        for attempt in 0..<modes.count {
            let (data, status) = rawFetch(url, mode: modes[attempt])
            if let data, !data.isEmpty {
                return .success(data)
            }
            lastStatus = status
            if attempt < delays.count && !isCancelled {
                Thread.sleep(forTimeInterval: delays[attempt])
            }
        }
        if isSegment {
            return .failure(HLError.segmentFailed(index + 1, total, lastStatus))
        }
        return .failure(HLError.requestFailed(lastStatus))
    }

    private func fetchText(_ url: URL) -> String? {
        guard case .success(let data) = fetchWithRetry(url) else { return nil }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
    }

    // MARK: - 转封装（AVAssetReader/Writer，避免 AVAssetExportSession 在 iOS 26 上崩溃）

    private func remux(from ts: URL, toBase base: URL) -> URL? {
        let asset = AVURLAsset(url: ts)
        let tracks = asset.tracks.filter { $0.mediaType == .video || $0.mediaType == .audio }
        guard !tracks.isEmpty else { return nil }

        for fileType in [AVFileType.mp4, AVFileType.mov] {
            if let url = writeRemux(asset: asset, tracks: tracks, base: base, fileType: fileType) {
                return url
            }
        }
        return nil
    }

    private func writeRemux(asset: AVURLAsset, tracks: [AVAssetTrack], base: URL, fileType: AVFileType) -> URL? {
        let ext = (fileType == .mov) ? "mov" : "mp4"
        let dest = base.appendingPathExtension(ext)
        try? FileManager.default.removeItem(at: dest)

        guard let reader = try? AVAssetReader(asset: asset),
              let writer = try? AVAssetWriter(outputURL: dest, fileType: fileType) else { return nil }

        var pairs: [(AVAssetReaderTrackOutput, AVAssetWriterInput)] = []
        for track in tracks {
            // 必须带格式描述，否则 passthrough 的 writer input 无法确定轨道格式，append 会失败
            var hint: CMFormatDescription?
            if let first = track.formatDescriptions.first {
                hint = (first as! CMFormatDescription)
            }

            let writerInput = AVAssetWriterInput(mediaType: track.mediaType,
                                                 outputSettings: nil,
                                                 sourceFormatHint: hint)
            writerInput.expectsMediaDataInRealTime = false
            guard writer.canAdd(writerInput) else { continue }

            let readerOutput = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
            readerOutput.alwaysCopiesSampleData = false
            guard reader.canAdd(readerOutput) else { continue }

            writer.add(writerInput)
            reader.add(readerOutput)
            pairs.append((readerOutput, writerInput))
        }
        guard !pairs.isEmpty else { return nil }

        guard reader.startReading(), writer.startWriting() else { return nil }
        writer.startSession(atSourceTime: .zero)

        var active = pairs
        var appendedAny = false
        while !active.isEmpty {
            if reader.status == .failed { break }
            var progressed = false
            var index = active.count - 1
            while index >= 0 {
                let (output, input) = active[index]
                if input.isReadyForMoreMediaData {
                    if let sample = output.copyNextSampleBuffer() {
                        if input.append(sample) {
                            appendedAny = true
                            progressed = true
                        } else {
                            input.markAsFinished()
                            active.remove(at: index)
                            progressed = true
                        }
                    } else {
                        input.markAsFinished()
                        active.remove(at: index)
                        progressed = true
                    }
                }
                index -= 1
            }
            if !progressed {
                Thread.sleep(forTimeInterval: 0.005)
            }
        }

        let sem = DispatchSemaphore(value: 0)
        writer.finishWriting { sem.signal() }
        _ = sem.wait(timeout: .now() + 180)

        guard appendedAny, writer.status == .completed else {
            try? FileManager.default.removeItem(at: dest)
            return nil
        }
        return dest
    }

    // MARK: - AES-128

    static func sequenceIV(_ index: Int) -> Data {
        var be = UInt64(index).bigEndian
        let bytes = withUnsafeBytes(of: &be) { Data($0) }
        var out = Data(repeating: 0, count: 8)
        out.append(bytes)
        return out
    }

    static func dataFromHex(_ hex: String) -> Data? {
        var s = hex.lowercased()
        if s.hasPrefix("0x") { s = String(s.dropFirst(2)) }
        guard s.count % 2 == 0 else { return nil }
        var data = Data()
        var idx = s.startIndex
        while idx < s.endIndex {
            let next = s.index(idx, offsetBy: 2)
            guard let byte = UInt8(s[idx..<next], radix: 16) else { return nil }
            data.append(byte)
            idx = next
        }
        return data
    }

    static func aes128Decrypt(_ data: Data, key: Data, iv: Data) -> Data? {
        guard key.count == kCCKeySizeAES128 else { return nil }
        var ivData = iv
        if ivData.count < 16 {
            ivData.append(Data(repeating: 0, count: 16 - ivData.count))
        }
        if ivData.count > 16 {
            ivData = Data(ivData.prefix(16))
        }

        let outLength = data.count + kCCBlockSizeAES128
        var out = Data(count: outLength)
        var moved = 0

        let status = out.withUnsafeMutableBytes { outPtr -> CCCryptorStatus in
            data.withUnsafeBytes { dataPtr -> CCCryptorStatus in
                key.withUnsafeBytes { keyPtr -> CCCryptorStatus in
                    ivData.withUnsafeBytes { ivPtr -> CCCryptorStatus in
                        CCCrypt(CCOperation(kCCDecrypt),
                                CCAlgorithm(kCCAlgorithmAES),
                                CCOptions(kCCOptionPKCS7Padding),
                                keyPtr.baseAddress, key.count,
                                ivPtr.baseAddress,
                                dataPtr.baseAddress, data.count,
                                outPtr.baseAddress, outLength,
                                &moved)
                    }
                }
            }
        }
        guard status == kCCSuccess else { return nil }
        return out.prefix(moved)
    }
}
