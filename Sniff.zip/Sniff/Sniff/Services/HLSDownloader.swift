import Foundation
import AVFoundation
import CommonCrypto

/// HLS（m3u8）下载器：
/// 1. 读主播放列表，选最高码率子列表
/// 2. 解析分片列表与 EXT-X-KEY（AES-128）
/// 3. 逐片下载、解密、按顺序写入单个 .ts
/// 4. 本地 TS 转封装成 MP4
final class HLSDownloader {

    enum HLError: LocalizedError {
        case requestFailed
        case badPlaylist
        case noSegments
        case decryptFailed
        case remuxFailed
        case cancelled

        var errorDescription: String? {
            switch self {
            case .requestFailed:  return "m3u8 请求失败（可能被防盗链拦截）"
            case .badPlaylist:    return "m3u8 解析失败"
            case .noSegments:     return "播放列表里没有分片"
            case .decryptFailed:  return "分片解密失败"
            case .remuxFailed:    return "分片已下载，但转 MP4 失败"
            case .cancelled:      return "已取消"
            }
        }
    }

    private struct Segment {
        let url: URL
        let keyURL: URL?
        let iv: Data?
    }

    private let referer: String
    private let userAgent: String
    private let workDir: URL
    private var session: URLSession!
    private var cancelled = false
    private var paused = false
    private let lock = NSLock()

    init(referer: String, userAgent: String, workDir: URL) {
        self.referer = referer
        self.userAgent = userAgent
        self.workDir = workDir
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 600
        cfg.httpMaximumConnectionsPerHost = 4
        session = URLSession(configuration: cfg)
    }

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
        session.invalidateAndCancel()
    }

    func pause() {
        lock.lock(); paused = true; lock.unlock()
    }

    func resume() {
        lock.lock(); paused = false; lock.unlock()
    }

    private var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    private var isPaused: Bool {
        lock.lock(); defer { lock.unlock() }
        return paused
    }

    // MARK: - 入口

    func run(playlistURL: URL,
             progress: @escaping (Double) -> Void,
             completion: @escaping (Result<URL, Error>) -> Void) {
        DispatchQueue.global(qos: .utility).async {
            let result = self.work(playlistURL: playlistURL, progress: progress)
            DispatchQueue.main.async { completion(result) }
        }
    }

    // MARK: - 主流程

    private func work(playlistURL: URL, progress: @escaping (Double) -> Void) -> Result<URL, Error> {
        guard var text = fetchText(playlistURL) else { return .failure(HLError.requestFailed) }
        var base = playlistURL

        // 主播放列表：挑最高码率
        if text.contains("#EXT-X-STREAM-INF") {
            guard let variant = bestVariant(in: text, base: playlistURL),
                  let sub = fetchText(variant) else { return .failure(HLError.badPlaylist) }
            base = variant
            text = sub
        }

        let segments = parseSegments(text, base: base)
        guard !segments.isEmpty else { return .failure(HLError.noSegments) }

        let tsURL = workDir.appendingPathComponent("hls_\(UUID().uuidString).ts")
        FileManager.default.createFile(atPath: tsURL.path, contents: nil)
        guard let handle = try? FileHandle(forWritingTo: tsURL) else { return .failure(HLError.badPlaylist) }

        var keyCache: [String: Data] = [:]
        for (index, seg) in segments.enumerated() {
            while isPaused && !isCancelled {
                Thread.sleep(forTimeInterval: 0.2)
            }
            if isCancelled {
                try? handle.close()
                try? FileManager.default.removeItem(at: tsURL)
                return .failure(HLError.cancelled)
            }
            guard var data = fetchData(seg.url) else {
                try? handle.close()
                try? FileManager.default.removeItem(at: tsURL)
                return .failure(HLError.requestFailed)
            }
            if let keyURL = seg.keyURL {
                let key = keyURL.absoluteString
                if keyCache[key] == nil {
                    keyCache[key] = fetchData(keyURL)
                }
                guard let keyData = keyCache[key] else {
                    try? handle.close()
                    return .failure(HLError.decryptFailed)
                }
                let iv = seg.iv ?? Self.sequenceIV(index)
                guard let plain = Self.aes128Decrypt(data, key: keyData, iv: iv) else {
                    try? handle.close()
                    return .failure(HLError.decryptFailed)
                }
                data = plain
            }
            handle.write(data)
            progress(Double(index + 1) / Double(segments.count))
        }
        try? handle.close()

        guard let mp4 = remux(from: tsURL, toBase: tsURL.deletingPathExtension()) else {
            try? FileManager.default.removeItem(at: tsURL)
            return .failure(HLError.remuxFailed)
        }
        try? FileManager.default.removeItem(at: tsURL)
        return .success(mp4)
    }

    // MARK: - m3u8 解析

    private func bestVariant(in text: String, base: URL) -> URL? {
        let lines = text.components(separatedBy: "\n").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        var best: (bw: Int, url: URL)?
        for (i, line) in lines.enumerated() {
            guard line.hasPrefix("#EXT-X-STREAM-INF") else { continue }
            let attrs = attributes(line)
            let bw = Int(attrs["BANDWIDTH"] ?? "0") ?? 0
            var j = i + 1
            while j < lines.count && (lines[j].isEmpty || lines[j].hasPrefix("#")) { j += 1 }
            guard j < lines.count, let u = URL(string: lines[j], relativeTo: base)?.absoluteURL else { continue }
            if best == nil || bw > best!.bw { best = (bw, u) }
        }
        return best?.url
    }

    private func parseSegments(_ text: String, base: URL) -> [Segment] {
        var result: [Segment] = []
        var keyURL: URL?
        var iv: Data?
        var sequence = 0

        for raw in text.components(separatedBy: "\n") {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty { continue }

            if line.hasPrefix("#EXT-X-MEDIA-SEQUENCE:") {
                let value = line.replacingOccurrences(of: "#EXT-X-MEDIA-SEQUENCE:", with: "")
                sequence = Int(value.trimmingCharacters(in: .whitespaces)) ?? 0
            } else if line.hasPrefix("#EXT-X-KEY:") {
                let attrs = attributes(line)
                let method = (attrs["METHOD"] ?? "").uppercased()
                if method == "NONE" {
                    keyURL = nil
                    iv = nil
                } else if method == "AES-128" {
                    if let uri = attrs["URI"], let u = URL(string: uri, relativeTo: base)?.absoluteURL {
                        keyURL = u
                    }
                    if let hex = attrs["IV"] {
                        iv = Self.dataFromHex(hex)
                    }
                }
            } else if !line.hasPrefix("#") {
                guard let u = URL(string: line, relativeTo: base)?.absoluteURL else { continue }
                result.append(Segment(url: u, keyURL: keyURL, iv: iv))
                sequence += 1
            }
        }
        return result
    }

    /// 解析 #EXT-X-KEY 这类标签的键值对（逗号分隔，引号内不算）
    private func attributes(_ line: String) -> [String: String] {
        guard let colon = line.firstIndex(of: ":") else { return [:] }
        let body = String(line[line.index(after: colon)...])
        var parts: [String] = []
        var current = ""
        var inQuotes = false
        for ch in body {
            if ch == "\"" {
                inQuotes.toggle()
                current.append(ch)
            } else if ch == "," && !inQuotes {
                parts.append(current)
                current = ""
            } else {
                current.append(ch)
            }
        }
        if !current.isEmpty { parts.append(current) }

        var dict: [String: String] = [:]
        for part in parts {
            let kv = part.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            guard kv.count == 2 else { continue }
            let key = String(kv[0]).trimmingCharacters(in: .whitespaces)
            let value = String(kv[1]).trimmingCharacters(in: .whitespaces)
                .replacingOccurrences(of: "\"", with: "")
            dict[key] = value
        }
        return dict
    }

    // MARK: - 网络（同步包装，跑在后台队列）

    private func fetchData(_ url: URL) -> Data? {
        if isCancelled { return nil }
        var result: Data?
        let sem = DispatchSemaphore(value: 0)
        let req = MediaHeaders.request(url: url, referer: referer, userAgent: userAgent)
        session.dataTask(with: req) { data, _, _ in
            result = data
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 60)
        return result
    }

    private func fetchText(_ url: URL) -> String? {
        guard let data = fetchData(url) else { return nil }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
    }

    // MARK: - 转封装

    private func remux(from ts: URL, toBase base: URL) -> URL? {
        let asset = AVURLAsset(url: ts)
        let presets = [AVAssetExportPresetPassthrough, AVAssetExportPresetHighestQuality]
        for preset in presets {
            guard let exporter = AVAssetExportSession(asset: asset, presetName: preset) else { continue }
            let types: [AVFileType] = [.mp4, .mov]
            for type in types where exporter.supportedFileTypes.contains(type) {
                let ext = (type == .mov) ? "mov" : "mp4"
                let dest = base.appendingPathExtension(ext)
                try? FileManager.default.removeItem(at: dest)
                exporter.outputURL = dest
                exporter.outputFileType = type
                exporter.shouldOptimizeForNetworkUse = true
                let sem = DispatchSemaphore(value: 0)
                exporter.exportAsynchronously { sem.signal() }
                _ = sem.wait(timeout: .now() + 900)
                if exporter.status == .completed {
                    return dest
                }
            }
        }
        return nil
    }

    // MARK: - AES-128

    static func sequenceIV(_ index: Int) -> Data {
        var be = UInt64(index).bigEndian
        let bytes = withUnsafeBytes(of: &be) { Data($0) }
        var out = Data(repeating: 0, count: 8)
        out.append(bytes)
        return out
    }

    static func dataFromHex(_ hex: String) -> Data? {
        var s = hex.lowercased()
        if s.hasPrefix("0x") { s = String(s.dropFirst(2)) }
        guard s.count % 2 == 0 else { return nil }
        var data = Data()
        var idx = s.startIndex
        while idx < s.endIndex {
            let next = s.index(idx, offsetBy: 2)
            guard let byte = UInt8(s[idx..<next], radix: 16) else { return nil }
            data.append(byte)
            idx = next
        }
        return data
    }

    static func aes128Decrypt(_ data: Data, key: Data, iv: Data) -> Data? {
        guard key.count == kCCKeySizeAES128 else { return nil }
        var ivData = iv
        if ivData.count < 16 {
            ivData.append(Data(repeating: 0, count: 16 - ivData.count))
        }
        if ivData.count > 16 {
            ivData = Data(ivData.prefix(16))
        }

        let outLength = data.count + kCCBlockSizeAES128
        var out = Data(count: outLength)
        var moved = 0

        let status = out.withUnsafeMutableBytes { outPtr -> CCCryptorStatus in
            data.withUnsafeBytes { dataPtr -> CCCryptorStatus in
                key.withUnsafeBytes { keyPtr -> CCCryptorStatus in
                    ivData.withUnsafeBytes { ivPtr -> CCCryptorStatus in
                        CCCrypt(CCOperation(kCCDecrypt),
                                CCAlgorithm(kCCAlgorithmAES),
                                CCOptions(kCCOptionPKCS7Padding),
                                keyPtr.baseAddress, key.count,
                                ivPtr.baseAddress,
                                dataPtr.baseAddress, data.count,
                                outPtr.baseAddress, outLength,
                                &moved)
                    }
                }
            }
        }
        guard status == kCCSuccess else { return nil }
        return out.prefix(moved)
    }
}
