import Foundation
import AVFoundation
import CommonCrypto

/// HLS（m3u8）下载器：
/// 1. 读主播放列表，选最高码率子列表
/// 2. 解析分片列表与 EXT-X-KEY（AES-128）
/// 3. 逐片下载（失败重试 + 降级请求头）、解密、按顺序写入单个 .ts
/// 4. 本地 TS 转封装成 MP4
final class HLSDownloader {

    enum HLError: LocalizedError {
        case requestFailed(Int)
        case segmentFailed(Int, Int, Int)
        case badPlaylist
        case noSegments
        case decryptFailed
        case remuxFailed
        case cancelled

        var errorDescription: String? {
            switch self {
            case .requestFailed(let code):
                return code == 0 ? "无法连接服务器（网络或域名不通）" : "播放列表请求失败（HTTP \(code)）"
            case .segmentFailed(let index, let total, let code):
                return "第 \(index)/\(total) 片失败（HTTP \(code)）"
            case .badPlaylist:    return "m3u8 解析失败"
            case .noSegments:     return "播放列表里没有分片"
            case .decryptFailed:  return "分片解密失败"
            case .remuxFailed:    return "分片已下载，但转 MP4 失败"
            case .cancelled:      return "已取消"
            }
        }
    }

    private struct Segment {
        let url: URL
        let keyURL: URL?
        let iv: Data?
    }

    private enum FetchMode {
        case full       // Referer + Origin + UA
        case noReferer  // 只带 UA
        case plain      // 裸请求
    }

    private let referer: String
    private let userAgent: String
    private let workDir: URL
    private var session: URLSession!
    private var cancelled = false
    private var paused = false
    private let lock = NSLock()

    init(referer: String, userAgent: String, workDir: URL) {
        self.referer = referer
        self.userAgent = userAgent
        self.workDir = workDir
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 600
        cfg.httpMaximumConnectionsPerHost = 4
        cfg.httpShouldSetCookies = true
        cfg.httpCookieStorage = HTTPCookieStorage.shared
        session = URLSession(configuration: cfg)
    }

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
        session.invalidateAndCancel()
    }

    func pause() {
        lock.lock(); paused = true; lock.unlock()
    }

    func resume() {
        lock.lock(); paused = false; lock.unlock()
    }

    private var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    private var isPaused: Bool {
        lock.lock(); defer { lock.unlock() }
        return paused
    }

    // MARK: - 入口

    func run(playlistURL: URL,
             progress: @escaping (Double) -> Void,
             completion: @escaping (Result<URL, Error>) -> Void) {
        DispatchQueue.global(qos: .utility).async {
            let result = self.work(playlistURL: playlistURL, progress: progress)
            DispatchQueue.main.async { completion(result) }
        }
    }

    // MARK: - 主流程

    private func work(playlistURL: URL, progress: @escaping (Double) -> Void) -> Result<URL, Error> {
        guard var text = fetchText(playlistURL) else { return .failure(HLError.requestFailed(0)) }
        var base = playlistURL

        // 主播放列表：挑最高码率
        if text.contains("#EXT-X-STREAM-INF") {
            guard let variant = bestVariant(in: text, base: playlistURL),
                  let sub = fetchText(variant) else { return .failure(HLError.badPlaylist) }
            base = variant
            text = sub
        }

        let segments = parseSegments(text, base: base)
        guard !segments.isEmpty else { return .failure(HLError.noSegments) }

        let tsURL = workDir.appendingPathComponent("hls_\(UUID().uuidString).ts")
        FileManager.default.createFile(atPath: tsURL.path, contents: nil)
        guard let handle = try? FileHandle(forWritingTo: tsURL) else { return .failure(HLError.badPlaylist) }

        var keyCache: [String: Data] = [:]
        for (index, seg) in segments.enumerated() {
            while isPaused && !isCancelled {
                Thread.sleep(forTimeInterval: 0.2)
            }
            if isCancelled {
                try? handle.close()
                try? FileManager.default.removeItem(at: tsURL)
                return .failure(HLError.cancelled)
            }

            let fetched = fetchWithRetry(seg.url, isSegment: true, index: index, total: segments.count)
            var data: Data
            switch fetched {
            case .success(let d):
                data = d
            case .failure(let error):
                try? handle.close()
                try? FileManager.default.removeItem(at: tsURL)
                return .failure(error)
            }

            if let keyURL = seg.keyURL {
                let key = keyURL.absoluteString
                if keyCache[key] == nil {
                    if case .success(let kd) = fetchWithRetry(keyURL) {
                        keyCache[key] = kd
                    }
                }
                guard let keyData = keyCache[key] else {
                    try? handle.close()
                    return .failure(HLError.decryptFailed)
                }
                let iv = seg.iv ?? Self.sequenceIV(index)
                guard let plain = Self.aes128Decrypt(data, key: keyData, iv: iv) else {
                    try? handle.close()
                    return .failure(HLError.decryptFailed)
                }
                data = plain
            }

            handle.write(data)
            progress(Double(index + 1) / Double(segments.count))
        }
        try? handle.close()

        guard let mp4 = remux(from: tsURL, toBase: tsURL.deletingPathExtension()) else {
            try? FileManager.default.removeItem(at: tsURL)
            return .failure(HLError.remuxFailed)
        }
        try? FileManager.default.removeItem(at: tsURL)
        return .success(mp4)
    }

    // MARK: - m3u8 解析

    private func bestVariant(in text: String, base: URL) -> URL? {
        let lines = text.components(separatedBy: "\n").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        var best: (bw: Int, url: URL)?
        for (i, line) in lines.enumerated() {
            guard line.hasPrefix("#EXT-X-STREAM-INF") else { continue }
            let attrs = attributes(line)
            let bw = Int(attrs["BANDWIDTH"] ?? "0") ?? 0
            var j = i + 1
            while j < lines.count && (lines[j].isEmpty || lines[j].hasPrefix("#")) { j += 1 }
            guard j < lines.count, let u = URL(string: lines[j], relativeTo: base)?.absoluteURL else { continue }
            if best == nil || bw > best!.bw { best = (bw, u) }
        }
        return best?.url
    }

    private func parseSegments(_ text: String, base: URL) -> [Segment] {
        var result: [Segment] = []
        var keyURL: URL?
        var iv: Data?

        for raw in text.components(separatedBy: "\n") {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty { continue }

            if line.hasPrefix("#EXT-X-KEY:") {
                let attrs = attributes(line)
                let method = (attrs["METHOD"] ?? "").uppercased()
                if method == "NONE" {
                    keyURL = nil
                    iv = nil
                } else if method == "AES-128" {
                    if let uri = attrs["URI"], let u = URL(string: uri, relativeTo: base)?.absoluteURL {
                        keyURL = u
                    }
                    if let hex = attrs["IV"] {
                        iv = Self.dataFromHex(hex)
                    }
                }
            } else if !line.hasPrefix("#") {
                guard let u = URL(string: line, relativeTo: base)?.absoluteURL else { continue }
                result.append(Segment(url: u, keyURL: keyURL, iv: iv))
            }
        }
        return result
    }

    /// 解析 #EXT-X-KEY 这类标签的键值对（逗号分隔，引号内不算）
    private func attributes(_ line: String) -> [String: String] {
        guard let colon = line.firstIndex(of: ":") else { return [:] }
        let body = String(line[line.index(after: colon)...])
        var parts: [String] = []
        var current = ""
        var inQuotes = false
        for ch in body {
            if ch == "\"" {
                inQuotes.toggle()
                current.append(ch)
            } else if ch == "," && !inQuotes {
                parts.append(current)
                current = ""
            } else {
                current.append(ch)
            }
        }
        if !current.isEmpty { parts.append(current) }

        var dict: [String: String] = [:]
        for part in parts {
            let kv = part.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            guard kv.count == 2 else { continue }
            let key = String(kv[0]).trimmingCharacters(in: .whitespaces)
            let value = String(kv[1]).trimmingCharacters(in: .whitespaces)
                .replacingOccurrences(of: "\"", with: "")
            dict[key] = value
        }
        return dict
    }

    // MARK: - 网络（同步包装，跑在后台队列）

    private func rawFetch(_ url: URL, mode: FetchMode) -> (Data?, Int) {
        if isCancelled { return (nil, 0) }
        var data: Data?
        var status = 0
        let sem = DispatchSemaphore(value: 0)

        var req: URLRequest
        switch mode {
        case .full:
            req = MediaHeaders.request(url: url, referer: referer, userAgent: userAgent)
        case .noReferer:
            req = URLRequest(url: url)
            req.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        case .plain:
            req = URLRequest(url: url)
        }

        session.dataTask(with: req) { d, resp, _ in
            data = d
            if let http = resp as? HTTPURLResponse {
                status = http.statusCode
            } else {
                status = (d == nil) ? 0 : 200
            }
            sem.signal()
        }.resume()

        _ = sem.wait(timeout: .now() + 45)
        return (data, status)
    }

    /// 最多 4 次：带完整头 → 带完整头 → 只带 UA → 裸请求
    private func fetchWithRetry(_ url: URL, isSegment: Bool = false, index: Int = 0, total: Int = 0) -> Result<Data, Error> {
        let modes: [FetchMode] = [.full, .full, .noReferer, .plain]
        let delays: [TimeInterval] = [0.6, 1.5, 3.0]
        var lastStatus = 0

        for attempt in 0..<modes.count {
            let (data, status) = rawFetch(url, mode: modes[attempt])
            if let data, !data.isEmpty {
                return .success(data)
            }
            lastStatus = status
            if attempt < delays.count {
                Thread.sleep(forTimeInterval: delays[attempt])
            }
        }
        if isSegment {
            return .failure(HLError.segmentFailed(index + 1, total, lastStatus))
        }
        return .failure(HLError.requestFailed(lastStatus))
    }

    private func fetchText(_ url: URL) -> String? {
        guard case .success(let data) = fetchWithRetry(url) else { return nil }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1)
    }

    // MARK: - 转封装

    private func remux(from ts: URL, toBase base: URL) -> URL? {
        let asset = AVURLAsset(url: ts)
        let presets = [AVAssetExportPresetPassthrough, AVAssetExportPresetHighestQuality]
        for preset in presets {
            guard let exporter = AVAssetExportSession(asset: asset, presetName: preset) else { continue }
            let types: [AVFileType] = [.mp4, .mov]
            for type in types where exporter.supportedFileTypes.contains(type) {
                let ext = (type == .mov) ? "mov" : "mp4"
                let dest = base.appendingPathExtension(ext)
                try? FileManager.default.removeItem(at: dest)
                exporter.outputURL = dest
                exporter.outputFileType = type
                exporter.shouldOptimizeForNetworkUse = true
                let sem = DispatchSemaphore(value: 0)
                exporter.exportAsynchronously { sem.signal() }
                _ = sem.wait(timeout: .now() + 900)
                if exporter.status == .completed {
                    return dest
                }
            }
        }
        return nil
    }

    // MARK: - AES-128

    static func sequenceIV(_ index: Int) -> Data {
        var be = UInt64(index).bigEndian
        let bytes = withUnsafeBytes(of: &be) { Data($0) }
        var out = Data(repeating: 0, count: 8)
        out.append(bytes)
        return out
    }

    static func dataFromHex(_ hex: String) -> Data? {
        var s = hex.lowercased()
        if s.hasPrefix("0x") { s = String(s.dropFirst(2)) }
        guard s.count % 2 == 0 else { return nil }
        var data = Data()
        var idx = s.startIndex
        while idx < s.endIndex {
            let next = s.index(idx, offsetBy: 2)
            guard let byte = UInt8(s[idx..<next], radix: 16) else { return nil }
            data.append(byte)
            idx = next
        }
        return data
    }

    static func aes128Decrypt(_ data: Data, key: Data, iv: Data) -> Data? {
        guard key.count == kCCKeySizeAES128 else { return nil }
        var ivData = iv
        if ivData.count < 16 {
            ivData.append(Data(repeating: 0, count: 16 - ivData.count))
        }
        if ivData.count > 16 {
            ivData = Data(ivData.prefix(16))
        }

        let outLength = data.count + kCCBlockSizeAES128
        var out = Data(count: outLength)
        var moved = 0

        let status = out.withUnsafeMutableBytes { outPtr -> CCCryptorStatus in
            data.withUnsafeBytes { dataPtr -> CCCryptorStatus in
                key.withUnsafeBytes { keyPtr -> CCCryptorStatus in
                    ivData.withUnsafeBytes { ivPtr -> CCCryptorStatus in
                        CCCrypt(CCOperation(kCCDecrypt),
                                CCAlgorithm(kCCAlgorithmAES),
                                CCOptions(kCCOptionPKCS7Padding),
                                keyPtr.baseAddress, key.count,
                                ivPtr.baseAddress,
                                dataPtr.baseAddress, data.count,
                                outPtr.baseAddress, outLength,
                                &moved)
                    }
                }
            }
        }
        guard status == kCCSuccess else { return nil }
        return out.prefix(moved)
    }
}
