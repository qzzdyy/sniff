import Foundation
import UIKit
import AVFoundation

/// 视频缩略图加载器（按 URL 缓存，避免列表滚动时反复抽帧）
final class ThumbnailLoader {
    static let shared = ThumbnailLoader()

    private let cache = NSCache<NSString, UIImage>()
    private let queue = DispatchQueue(label: "sniff.thumb", qos: .utility, attributes: .concurrent)

    private init() {
        cache.countLimit = 200
    }

    func cached(for url: URL) -> UIImage? {
        cache.object(forKey: url.absoluteString as NSString)
    }

    func image(for url: URL, completion: @escaping (UIImage?) -> Void) {
        let key = url.absoluteString as NSString
        if let img = cache.object(forKey: key) {
            completion(img)
            return
        }
        queue.async {
            let asset = AVURLAsset(url: url)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            generator.maximumSize = CGSize(width: 240, height: 240)
            generator.requestedTimeToleranceBefore = CMTime(seconds: 1, preferredTimescale: 600)
            generator.requestedTimeToleranceAfter = CMTime(seconds: 1, preferredTimescale: 600)
            let time = CMTime(seconds: 1, preferredTimescale: 600)
            let cg = try? generator.copyCGImage(at: time, actualTime: nil)
            let img = cg.map { UIImage(cgImage: $0) }
            DispatchQueue.main.async {
                if let img {
                    self.cache.setObject(img, forKey: key)
                }
                completion(img)
            }
        }
    }
}
