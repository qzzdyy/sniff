import Foundation
import UIKit
import Photos

/// 一条下载任务
struct DownloadTask: Identifiable, Equatable {
    let id = UUID()
    let item: ResourceItem
    var progress: Double = 0
    var status: Status = .running
    var localURL: URL?
    /// 直链暂停后用于续传
    var resumeData: Data?

    enum Status: Equatable {
        case running
        case paused
        case done
        case failed(String)

        var text: String {
            switch self {
            case .running: return "下载中"
            case .paused:  return "已暂停"
            case .done:    return "已完成"
            case .failed(let e): return "失败：\(e)"
            }
        }
    }

    var isRunning: Bool {
        if case .running = status { return true }
        return false
    }

    var isPaused: Bool {
        if case .paused = status { return true }
        return false
    }

    var isDone: Bool {
        if case .done = status { return true }
        return false
    }
}

/// 下载管理：直链走 URLSession；m3u8 走 HLSDownloader（分片下载 + 解密 + 转封装）
final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {

    @Published private(set) var tasks: [DownloadTask] = []

    private var session: URLSession!
    private var mapping: [Int: UUID] = [:]
    private var liveTasks: [UUID: URLSessionDownloadTask] = [:]
    private var hlsJobs: [UUID: HLSDownloader] = [:]
    private let lock = NSLock()

    override init() {
        super.init()
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 3600
        session = URLSession(configuration: cfg, delegate: self, delegateQueue: nil)
    }

    // MARK: - 对外接口

    func download(_ item: ResourceItem) {
        guard !tasks.contains(where: { $0.item == item && $0.isRunning }) else { return }
        for old in tasks where old.item == item && !old.isRunning {
            remove(old)
        }
        let task = DownloadTask(item: item)
        DispatchQueue.main.async { self.tasks.insert(task, at: 0) }

        if item.kind == .hls {
            startHLS(task)
        } else {
            startDirect(task)
        }
    }

    func retry(_ task: DownloadTask) {
        guard !task.isRunning else { return }
        let item = task.item
        remove(task)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            self.download(item)
        }
    }

    /// 暂停：直链用 resumeData 续传，HLS 在分片之间挂起
    func pause(_ task: DownloadTask) {
        guard task.isRunning else { return }
        lock.lock()
        let hls = hlsJobs[task.id]
        let live = liveTasks.removeValue(forKey: task.id)
        lock.unlock()

        if let hls {
            hls.pause()
            update(id: task.id) { $0.status = .paused }
            return
        }
        if let live {
            live.cancel(byProducingResumeData: { data in
                self.update(id: task.id) { $0.status = .paused; $0.resumeData = data }
            })
        } else {
            update(id: task.id) { $0.status = .paused }
        }
    }

    /// 继续
    func resume(_ task: DownloadTask) {
        guard task.isPaused else { return }

        lock.lock()
        let hls = hlsJobs[task.id]
        lock.unlock()
        if let hls {
            hls.resume()
            update(id: task.id) { $0.status = .running }
            return
        }

        update(id: task.id) { $0.status = .running }
        if let data = task.resumeData, !data.isEmpty {
            let urlTask = session.downloadTask(withResumeData: data)
            lock.lock()
            mapping[urlTask.taskIdentifier] = task.id
            liveTasks[task.id] = urlTask
            lock.unlock()
            urlTask.resume()
        } else {
            startDirect(task)
        }
    }

    func remove(_ task: DownloadTask) {
        lock.lock()
        if let t = liveTasks.removeValue(forKey: task.id) { t.cancel() }
        if let h = hlsJobs.removeValue(forKey: task.id) { h.cancel() }
        lock.unlock()
        if let url = task.localURL { try? FileManager.default.removeItem(at: url) }
        DispatchQueue.main.async { self.tasks.removeAll { $0.id == task.id } }
    }

    func task(for item: ResourceItem) -> DownloadTask? {
        tasks.first { $0.item == item }
    }

    // MARK: - 直链下载

    private func startDirect(_ task: DownloadTask) {
        let request = MediaHeaders.request(for: task.item)
        let urlTask = session.downloadTask(with: request)
        lock.lock()
        mapping[urlTask.taskIdentifier] = task.id
        liveTasks[task.id] = urlTask
        lock.unlock()
        urlTask.resume()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        lock.lock()
        let id = mapping.removeValue(forKey: downloadTask.taskIdentifier)
        lock.unlock()
        guard let id else { return }

        guard let item = tasks.first(where: { $0.id == id })?.item else { return }
        var ext = (downloadTask.response?.suggestedFilename as NSString?)?.pathExtension ?? ""
        if ext.isEmpty { ext = item.url.pathExtension }
        if ext.isEmpty {
            switch item.kind {
            case .image: ext = "jpg"
            case .audio: ext = "m4a"
            default: ext = "mp4"
            }
        }
        let dest = destination(for: id, ext: ext.lowercased())
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            update(id: id) { $0.progress = 1; $0.status = .done; $0.localURL = dest }
        } catch {
            update(id: id) { $0.status = .failed(error.localizedDescription) }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        lock.lock()
        let id = mapping[downloadTask.taskIdentifier]
        lock.unlock()
        guard let id, totalBytesExpectedToWrite > 0 else { return }
        let p = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        update(id: id) { $0.progress = p }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock()
        let id = mapping.removeValue(forKey: task.taskIdentifier)
        lock.unlock()
        guard let id, let error else { return }
        // 主动暂停/删除会触发 -999，不算失败
        if let urlError = error as? URLError, urlError.code == .cancelled { return }
        update(id: id) { $0.status = .failed(error.localizedDescription) }
    }

    // MARK: - HLS 下载

    private func startHLS(_ task: DownloadTask) {
        let downloader = HLSDownloader(referer: MediaHeaders.referer(for: task.item),
                                       userAgent: UserAgentPreset.current.ua,
                                       workDir: documentsDir())
        lock.lock()
        hlsJobs[task.id] = downloader
        lock.unlock()

        downloader.run(playlistURL: task.item.url, progress: { [weak self] p in
            self?.update(id: task.id) { $0.progress = p }
        }, completion: { [weak self] result in
            guard let self else { return }
            self.lock.lock()
            self.hlsJobs.removeValue(forKey: task.id)
            self.lock.unlock()
            switch result {
            case .success(let url):
                self.update(id: task.id) { $0.progress = 1; $0.status = .done; $0.localURL = url }
            case .failure(let error):
                self.update(id: task.id) { $0.status = .failed(error.localizedDescription) }
            }
        })
    }

    // MARK: - 保存到相册

    func saveVideoToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        let ext = local.pathExtension.lowercased()
        if ext != "mp4" && ext != "mov" && ext != "m4v" {
            completion(.failure(NSError(domain: "Sniff", code: 4, userInfo: [
                NSLocalizedDescriptionKey: "相册只支持 mp4/mov，当前文件是 .\(ext)"
            ])))
            return
        }
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized else {
                completion(.failure(NSError(domain: "Sniff", code: 1, userInfo: [
                    NSLocalizedDescriptionKey: "没有相册写入权限，请到设置里允许"
                ])))
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: local)
            }) { ok, err in
                DispatchQueue.main.async {
                    if ok {
                        completion(.success(()))
                    } else {
                        completion(.failure(err ?? NSError(domain: "Sniff", code: 2, userInfo: [
                            NSLocalizedDescriptionKey: "视频格式不受支持"
                        ])))
                    }
                }
            }
        }
    }

    func saveImageToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized else {
                completion(.failure(NSError(domain: "Sniff", code: 1, userInfo: [
                    NSLocalizedDescriptionKey: "没有相册写入权限，请到设置里允许"
                ])))
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: local)
            }) { ok, err in
                DispatchQueue.main.async {
                    if ok {
                        completion(.success(()))
                    } else {
                        completion(.failure(err ?? NSError(domain: "Sniff", code: 2, userInfo: [
                            NSLocalizedDescriptionKey: "图片格式不受支持"
                        ])))
                    }
                }
            }
        }
    }

    // MARK: - 工具

    func documentsDir() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Sniff", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private func destination(for id: UUID, ext: String) -> URL {
        documentsDir().appendingPathComponent("\(id.uuidString).\(ext)")
    }

    private func update(id: UUID, _ block: @escaping (inout DownloadTask) -> Void) {
        DispatchQueue.main.async {
            guard let idx = self.tasks.firstIndex(where: { $0.id == id }) else { return }
            var t = self.tasks[idx]
            block(&t)
            self.tasks[idx] = t
        }
    }
}
