import Foundation
import UIKit
import Photos
import AVFoundation

/// 一条下载任务
struct DownloadTask: Identifiable, Equatable {
    let id = UUID()
    let item: ResourceItem
    var progress: Double = 0
    var status: Status = .running
    var localURL: URL?

    enum Status: Equatable {
        case running
        case done
        case failed(String)

        var text: String {
            switch self {
            case .running: return "下载中"
            case .done: return "已完成"
            case .failed(let e): return "失败：\(e)"
            }
        }
    }

    var isRunning: Bool {
        if case .running = status { return true }
        return false
    }
}

/// 下载管理：普通直链走 URLSession；m3u8 走 AVAssetExportSession 合成 mp4
final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {

    @Published private(set) var tasks: [DownloadTask] = []

    private var session: URLSession!
    /// URLSession taskIdentifier -> DownloadTask.id
    private var mapping: [Int: UUID] = [:]
    /// DownloadTask.id -> 进行中的 URLSession 任务
    private var liveTasks: [UUID: URLSessionDownloadTask] = [:]
    /// DownloadTask.id -> 进行中的 HLS 导出
    private var hlsSessions: [UUID: AVAssetExportSession] = [:]
    private var progressTimer: Timer?
    private let lock = NSLock()

    override init() {
        super.init()
        session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
    }

    // MARK: - 对外

    func download(_ item: ResourceItem) {
        guard !tasks.contains(where: { $0.item == item && $0.isRunning }) else { return }
        // 同一个资源之前的失败记录先清掉，避免列表里重复
        for old in tasks where old.item == item && !old.isRunning {
            remove(old)
        }
        let task = DownloadTask(item: item)
        DispatchQueue.main.async { self.tasks.insert(task, at: 0) }

        if item.kind == .hls {
            exportHLS(task)
        } else {
            startDirect(task)
        }
    }

    func retry(_ task: DownloadTask) {
        guard !task.isRunning else { return }
        remove(task)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.download(task.item)
        }
    }

    func remove(_ task: DownloadTask) {
        lock.lock()
        if let t = liveTasks.removeValue(forKey: task.id) { t.cancel() }
        if let h = hlsSessions.removeValue(forKey: task.id) { h.cancelExport() }
        lock.unlock()
        if let url = task.localURL { try? FileManager.default.removeItem(at: url) }
        DispatchQueue.main.async { self.tasks.removeAll { $0.id == task.id } }
    }

    func task(for item: ResourceItem) -> DownloadTask? {
        tasks.first { $0.item == item }
    }

    // MARK: - 直链下载

    private func startDirect(_ task: DownloadTask) {
        let urlTask = session.downloadTask(with: task.item.url)
        lock.lock()
        mapping[urlTask.taskIdentifier] = task.id
        liveTasks[task.id] = urlTask
        lock.unlock()
        urlTask.resume()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        lock.lock()
        let id = mapping.removeValue(forKey: downloadTask.taskIdentifier)
        lock.unlock()
        guard let id else { return }

        let ext = (downloadTask.response?.suggestedFilename as NSString?)?.pathExtension ?? ""
        let dest = destination(for: id, ext: ext.isEmpty ? "bin" : ext)
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            update(id: id) { $0.progress = 1; $0.status = .done; $0.localURL = dest }
        } catch {
            update(id: id) { $0.status = .failed(error.localizedDescription) }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        lock.lock()
        let id = mapping[downloadTask.taskIdentifier]
        lock.unlock()
        guard let id, totalBytesExpectedToWrite > 0 else { return }
        let p = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        update(id: id) { $0.progress = p }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock()
        let id = mapping.removeValue(forKey: task.taskIdentifier)
        lock.unlock()
        guard let id, let error else { return }
        update(id: id) { $0.status = .failed(error.localizedDescription) }
    }

    // MARK: - HLS 合成 MP4

    private func exportHLS(_ task: DownloadTask) {
        let asset = AVURLAsset(url: task.item.url)
        guard let exporter = AVAssetExportSession(asset: asset,
                                                  presetName: AVAssetExportPresetHighestQuality) else {
            update(id: task.id) { $0.status = .failed("无法创建导出会话，链接可能不是标准 m3u8") }
            return
        }
        let dest = destination(for: task.id, ext: "mp4")
        try? FileManager.default.removeItem(at: dest)
        exporter.outputURL = dest
        exporter.outputFileType = .mp4
        exporter.shouldOptimizeForNetworkUse = true

        lock.lock()
        hlsSessions[task.id] = exporter
        lock.unlock()
        startProgressTimer()

        exporter.exportAsynchronously { [weak self] in
            guard let self else { return }
            self.lock.lock()
            self.hlsSessions.removeValue(forKey: task.id)
            self.lock.unlock()

            switch exporter.status {
            case .completed:
                self.update(id: task.id) { $0.progress = 1; $0.status = .done; $0.localURL = dest }
            case .cancelled:
                self.update(id: task.id) { $0.status = .failed("已取消") }
            default:
                let msg = exporter.error?.localizedDescription ?? "m3u8 合成失败"
                self.update(id: task.id) { $0.status = .failed(msg) }
            }
        }
    }

    private func startProgressTimer() {
        DispatchQueue.main.async {
            guard self.progressTimer == nil else { return }
            self.progressTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] timer in
                guard let self else { timer.invalidate(); return }
                self.lock.lock()
                let running = self.hlsSessions
                self.lock.unlock()
                if running.isEmpty {
                    timer.invalidate()
                    self.progressTimer = nil
                    return
                }
                for (id, exporter) in running {
                    let p = Double(exporter.progress)
                    self.update(id: id) { $0.progress = p }
                }
            }
        }
    }

    // MARK: - 保存到相册

    func saveVideoToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized else {
                completion(.failure(NSError(domain: "Sniff", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "没有相册写入权限，请到设置里允许"])))
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: local)
            }) { ok, err in
                DispatchQueue.main.async {
                    if ok {
                        completion(.success(()))
                    } else {
                        completion(.failure(err ?? NSError(domain: "Sniff", code: 2,
                            userInfo: [NSLocalizedDescriptionKey: "视频格式不受支持"])))
                    }
                }
            }
        }
    }

    func saveImageToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized else {
                completion(.failure(NSError(domain: "Sniff", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "没有相册写入权限，请到设置里允许"])))
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: local)
            }) { ok, err in
                DispatchQueue.main.async {
                    if ok {
                        completion(.success(()))
                    } else {
                        completion(.failure(err ?? NSError(domain: "Sniff", code: 2,
                            userInfo: [NSLocalizedDescriptionKey: "图片格式不受支持"])))
                    }
                }
            }
        }
    }

    // MARK: - 工具

    private func destination(for id: UUID, ext: String) -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Sniff", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("\(id.uuidString).\(ext)")
    }

    private func update(id: UUID, _ block: @escaping (inout DownloadTask) -> Void) {
        DispatchQueue.main.async {
            guard let idx = self.tasks.firstIndex(where: { $0.id == id }) else { return }
            var t = self.tasks[idx]
            block(&t)
            self.tasks[idx] = t
        }
    }
}
