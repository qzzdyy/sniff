import Foundation
import Photos

/// 一条下载任务的状态
struct DownloadTask: Identifiable {
    let id = UUID()
    let item: ResourceItem
    var progress: Double = 0
    var status: Status = .running
    var localURL: URL?

    enum Status {
        case running, done, failed(String)
        var text: String {
            switch self {
            case .running: return "下载中"
            case .done: return "已完成"
            case .failed(let e): return "失败：\(e)"
            }
        }
    }
}

final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published private(set) var tasks: [DownloadTask] = []

    private var session: URLSession!
    /// downloadTask.taskIdentifier -> ResourceItem.id
    private var mapping: [Int: UUID] = [:]
    private let lock = NSLock()

    override init() {
        super.init()
        session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
    }

    func download(_ item: ResourceItem) {
        guard !tasks.contains(where: { $0.item == item && $0.status == .running }) else { return }
        let task = DownloadTask(item: item)
        DispatchQueue.main.async { self.tasks.insert(task, at: 0) }

        let urlTask = session.downloadTask(with: item.url)
        lock.lock(); mapping[urlTask.taskIdentifier] = task.id; lock.unlock()
        urlTask.resume()
    }

    func remove(_ task: DownloadTask) {
        DispatchQueue.main.async { self.tasks.removeAll { $0.id == task.id } }
    }

    // MARK: - 保存到相册

    func saveVideoToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized else {
                completion(.failure(NSError(domain: "Sniff", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "没有相册写入权限，请在设置中允许"])))
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: local)
            }) { ok, err in
                DispatchQueue.main.async {
                    ok ? completion(.success(())) : completion(.failure(err ?? NSError(domain: "Sniff", code: 2)))
                }
            }
        }
    }

    func saveImageToAlbum(_ local: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let data = try? Data(contentsOf: local), let image = UIImage(data: data) else {
            completion(.failure(NSError(domain: "Sniff", code: 3,
                userInfo: [NSLocalizedDescriptionKey: "图片文件无法读取"])))
            return
        }
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
        completion(.success(()))
    }

    // MARK: - URLSessionDownloadDelegate

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        lock.lock(); let id = mapping.removeValue(forKey: downloadTask.taskIdentifier); lock.unlock()
        guard let id else { return }

        // 落到 App 沙盒 Documents/Sniff（开启文件共享后用户可从"文件"App 取走）
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Sniff", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = dir.appendingPathComponent(downloadTask.response?.suggestedFilename ?? id.uuidString)
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            update(id: id) { $0.status = .done; $0.localURL = dest }
        } catch {
            update(id: id) { $0.status = .failed(error.localizedDescription) }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        lock.lock(); let id = mapping[downloadTask.taskIdentifier]; lock.unlock()
        guard let id, totalBytesExpectedToWrite > 0 else { return }
        update(id: id) { $0.progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock(); let id = mapping.removeValue(forKey: task.taskIdentifier); lock.unlock()
        guard let id, let error else { return }
        update(id: id) { $0.status = .failed(error.localizedDescription) }
    }

    private func update(id: UUID, _ block: @escaping (inout DownloadTask) -> Void) {
        DispatchQueue.main.async {
            guard let idx = self.tasks.firstIndex(where: { $0.id == id }) else { return }
            var t = self.tasks[idx]
            block(&t)
            self.tasks[idx] = t
        }
    }
}
